/**
 */
package aadldesr;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Tprotocol</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see aadldesr.AadldesrPackage#getTprotocol()
 * @model
 * @generated
 */
public enum Tprotocol implements Enumerator {
	/**
	 * The '<em><b>HSER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #HSER_VALUE
	 * @generated
	 * @ordered
	 */
	HSER(0, "HSER", "HSER"),

	/**
	 * The '<em><b>ASER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ASER_VALUE
	 * @generated
	 * @ordered
	 */
	ASER(1, "ASER", "ASER"),

	/**
	 * The '<em><b>LSER</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LSER_VALUE
	 * @generated
	 * @ordered
	 */
	LSER(2, "LSER", "LSER");

	/**
	 * The '<em><b>HSER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>HSER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #HSER
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int HSER_VALUE = 0;

	/**
	 * The '<em><b>ASER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ASER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ASER
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ASER_VALUE = 1;

	/**
	 * The '<em><b>LSER</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>LSER</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #LSER
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int LSER_VALUE = 2;

	/**
	 * An array of all the '<em><b>Tprotocol</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final Tprotocol[] VALUES_ARRAY =
		new Tprotocol[] {
			HSER,
			ASER,
			LSER,
		};

	/**
	 * A public read-only list of all the '<em><b>Tprotocol</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<Tprotocol> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Tprotocol</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Tprotocol get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Tprotocol result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Tprotocol</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Tprotocol getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Tprotocol result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Tprotocol</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Tprotocol get(int value) {
		switch (value) {
			case HSER_VALUE: return HSER;
			case ASER_VALUE: return ASER;
			case LSER_VALUE: return LSER;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Tprotocol(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //Tprotocol
