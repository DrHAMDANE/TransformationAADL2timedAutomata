/**
 */
package aadldesr;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AAD Lspec</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link aadldesr.AADLspec#getCompose <em>Compose</em>}</li>
 *   <li>{@link aadldesr.AADLspec#getDatas <em>Datas</em>}</li>
 *   <li>{@link aadldesr.AADLspec#getProcessus <em>Processus</em>}</li>
 *   <li>{@link aadldesr.AADLspec#getThreads <em>Threads</em>}</li>
 *   <li>{@link aadldesr.AADLspec#getNom <em>Nom</em>}</li>
 * </ul>
 * </p>
 *
 * @see aadldesr.AadldesrPackage#getAADLspec()
 * @model
 * @generated
 */
public interface AADLspec extends EObject {
	/**
	 * Returns the value of the '<em><b>Compose</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Compose</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Compose</em>' containment reference.
	 * @see #setCompose(system)
	 * @see aadldesr.AadldesrPackage#getAADLspec_Compose()
	 * @model containment="true" required="true"
	 * @generated
	 */
	system getCompose();

	/**
	 * Sets the value of the '{@link aadldesr.AADLspec#getCompose <em>Compose</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Compose</em>' containment reference.
	 * @see #getCompose()
	 * @generated
	 */
	void setCompose(system value);

	/**
	 * Returns the value of the '<em><b>Datas</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.data}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Datas</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Datas</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getAADLspec_Datas()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<data> getDatas();

	/**
	 * Returns the value of the '<em><b>Processus</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.process}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Processus</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Processus</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getAADLspec_Processus()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<process> getProcessus();

	/**
	 * Returns the value of the '<em><b>Threads</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.thread}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Threads</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Threads</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getAADLspec_Threads()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<thread> getThreads();

	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nom</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see aadldesr.AadldesrPackage#getAADLspec_Nom()
	 * @model
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link aadldesr.AADLspec#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

} // AADLspec
