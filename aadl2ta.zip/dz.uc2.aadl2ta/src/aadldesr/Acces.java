/**
 */
package aadldesr;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Acces</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link aadldesr.Acces#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link aadldesr.Acces#getNom <em>Nom</em>}</li>
 * </ul>
 * </p>
 *
 * @see aadldesr.AadldesrPackage#getAcces()
 * @model
 * @generated
 */
public interface Acces extends EObject {
	/**
	 * Returns the value of the '<em><b>Protocol</b></em>' attribute.
	 * The literals are from the enumeration {@link aadldesr.Tprotocol}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Protocol</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protocol</em>' attribute.
	 * @see aadldesr.Tprotocol
	 * @see #setProtocol(Tprotocol)
	 * @see aadldesr.AadldesrPackage#getAcces_Protocol()
	 * @model
	 * @generated
	 */
	Tprotocol getProtocol();

	/**
	 * Sets the value of the '{@link aadldesr.Acces#getProtocol <em>Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Protocol</em>' attribute.
	 * @see aadldesr.Tprotocol
	 * @see #getProtocol()
	 * @generated
	 */
	void setProtocol(Tprotocol value);

	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nom</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see aadldesr.AadldesrPackage#getAcces_Nom()
	 * @model
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link aadldesr.Acces#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

} // Acces
