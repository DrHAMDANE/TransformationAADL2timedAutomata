/**
 */
package aadldesr;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see aadldesr.AadldesrPackage
 * @generated
 */
public interface AadldesrFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	AadldesrFactory eINSTANCE = aadldesr.impl.AadldesrFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>AAD Lspec</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>AAD Lspec</em>'.
	 * @generated
	 */
	AADLspec createAADLspec();

	/**
	 * Returns a new object of class '<em>system</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>system</em>'.
	 * @generated
	 */
	system createsystem();

	/**
	 * Returns a new object of class '<em>data</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>data</em>'.
	 * @generated
	 */
	data createdata();

	/**
	 * Returns a new object of class '<em>process</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>process</em>'.
	 * @generated
	 */
	process createprocess();

	/**
	 * Returns a new object of class '<em>thread</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>thread</em>'.
	 * @generated
	 */
	thread createthread();

	/**
	 * Returns a new object of class '<em>suprogram</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>suprogram</em>'.
	 * @generated
	 */
	suprogram createsuprogram();

	/**
	 * Returns a new object of class '<em>feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>feature</em>'.
	 * @generated
	 */
	feature createfeature();

	/**
	 * Returns a new object of class '<em>port</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>port</em>'.
	 * @generated
	 */
	port createport();

	/**
	 * Returns a new object of class '<em>Acces</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Acces</em>'.
	 * @generated
	 */
	Acces createAcces();

	/**
	 * Returns a new object of class '<em>connection</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>connection</em>'.
	 * @generated
	 */
	connection createconnection();

	/**
	 * Returns a new object of class '<em>annex</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>annex</em>'.
	 * @generated
	 */
	annex createannex();

	/**
	 * Returns a new object of class '<em>state</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>state</em>'.
	 * @generated
	 */
	state createstate();

	/**
	 * Returns a new object of class '<em>transition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>transition</em>'.
	 * @generated
	 */
	transition createtransition();

	/**
	 * Returns a new object of class '<em>connectionthread</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>connectionthread</em>'.
	 * @generated
	 */
	connectionthread createconnectionthread();

	/**
	 * Returns a new object of class '<em>parameter</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>parameter</em>'.
	 * @generated
	 */
	parameter createparameter();

	/**
	 * Returns a new object of class '<em>Port IN</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Port IN</em>'.
	 * @generated
	 */
	PortIN createPortIN();

	/**
	 * Returns a new object of class '<em>Port Out</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Port Out</em>'.
	 * @generated
	 */
	PortOut createPortOut();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	AadldesrPackage getAadldesrPackage();

} //AadldesrFactory
