/**
 */
package aadldesr;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>suprogram</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link aadldesr.suprogram#getSubcomponents <em>Subcomponents</em>}</li>
 *   <li>{@link aadldesr.suprogram#getAnnexe <em>Annexe</em>}</li>
 *   <li>{@link aadldesr.suprogram#getNom <em>Nom</em>}</li>
 *   <li>{@link aadldesr.suprogram#getParameterss <em>Parameterss</em>}</li>
 * </ul>
 * </p>
 *
 * @see aadldesr.AadldesrPackage#getsuprogram()
 * @model
 * @generated
 */
public interface suprogram extends EObject {
	/**
	 * Returns the value of the '<em><b>Subcomponents</b></em>' reference list.
	 * The list contents are of type {@link aadldesr.data}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subcomponents</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subcomponents</em>' reference list.
	 * @see aadldesr.AadldesrPackage#getsuprogram_Subcomponents()
	 * @model required="true"
	 * @generated
	 */
	EList<data> getSubcomponents();

	/**
	 * Returns the value of the '<em><b>Annexe</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Annexe</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Annexe</em>' containment reference.
	 * @see #setAnnexe(annex)
	 * @see aadldesr.AadldesrPackage#getsuprogram_Annexe()
	 * @model containment="true" required="true"
	 * @generated
	 */
	annex getAnnexe();

	/**
	 * Sets the value of the '{@link aadldesr.suprogram#getAnnexe <em>Annexe</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Annexe</em>' containment reference.
	 * @see #getAnnexe()
	 * @generated
	 */
	void setAnnexe(annex value);

	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nom</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see aadldesr.AadldesrPackage#getsuprogram_Nom()
	 * @model
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link aadldesr.suprogram#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Parameterss</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.parameter}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parameterss</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameterss</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getsuprogram_Parameterss()
	 * @model containment="true"
	 * @generated
	 */
	EList<parameter> getParameterss();

} // suprogram
