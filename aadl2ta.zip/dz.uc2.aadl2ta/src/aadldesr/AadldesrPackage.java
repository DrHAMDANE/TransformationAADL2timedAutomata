/**
 */
package aadldesr;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see aadldesr.AadldesrFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/OCL/Import ecore='http://www.eclipse.org/emf/2002/Ecore#/'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface AadldesrPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "aadldesr";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://aadldesr/1.0";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "aadldesr";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	AadldesrPackage eINSTANCE = aadldesr.impl.AadldesrPackageImpl.init();

	/**
	 * The meta object id for the '{@link aadldesr.impl.AADLspecImpl <em>AAD Lspec</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.AADLspecImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getAADLspec()
	 * @generated
	 */
	int AAD_LSPEC = 0;

	/**
	 * The feature id for the '<em><b>Compose</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AAD_LSPEC__COMPOSE = 0;

	/**
	 * The feature id for the '<em><b>Datas</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AAD_LSPEC__DATAS = 1;

	/**
	 * The feature id for the '<em><b>Processus</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AAD_LSPEC__PROCESSUS = 2;

	/**
	 * The feature id for the '<em><b>Threads</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AAD_LSPEC__THREADS = 3;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AAD_LSPEC__NOM = 4;

	/**
	 * The number of structural features of the '<em>AAD Lspec</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AAD_LSPEC_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>AAD Lspec</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AAD_LSPEC_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.systemImpl <em>system</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.systemImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getsystem()
	 * @generated
	 */
	int SYSTEM = 1;

	/**
	 * The feature id for the '<em><b>Subcomponents</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM__SUBCOMPONENTS = 0;

	/**
	 * The feature id for the '<em><b>Subcomponentsp</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM__SUBCOMPONENTSP = 1;

	/**
	 * The feature id for the '<em><b>Features</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM__FEATURES = 2;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM__NOM = 3;

	/**
	 * The number of structural features of the '<em>system</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>system</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.dataImpl <em>data</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.dataImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getdata()
	 * @generated
	 */
	int DATA = 2;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA__NOM = 1;

	/**
	 * The number of structural features of the '<em>data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>data</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.processImpl <em>process</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.processImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getprocess()
	 * @generated
	 */
	int PROCESS = 3;

	/**
	 * The feature id for the '<em><b>Subcd</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__SUBCD = 0;

	/**
	 * The feature id for the '<em><b>Subccompenets</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__SUBCCOMPENETS = 1;

	/**
	 * The feature id for the '<em><b>Connectiont</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__CONNECTIONT = 2;

	/**
	 * The feature id for the '<em><b>Features</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__FEATURES = 3;

	/**
	 * The feature id for the '<em><b>Connections</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__CONNECTIONS = 4;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS__NOM = 5;

	/**
	 * The number of structural features of the '<em>process</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>process</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROCESS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.threadImpl <em>thread</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.threadImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getthread()
	 * @generated
	 */
	int THREAD = 4;

	/**
	 * The feature id for the '<em><b>Dispatch protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD__DISPATCH_PROTOCOL = 0;

	/**
	 * The feature id for the '<em><b>Compute execution time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD__COMPUTE_EXECUTION_TIME = 1;

	/**
	 * The feature id for the '<em><b>Call</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD__CALL = 2;

	/**
	 * The feature id for the '<em><b>Annexe</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD__ANNEXE = 3;

	/**
	 * The feature id for the '<em><b>Features</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD__FEATURES = 4;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD__NOM = 5;

	/**
	 * The feature id for the '<em><b>Connections</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD__CONNECTIONS = 6;

	/**
	 * The number of structural features of the '<em>thread</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>thread</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THREAD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.suprogramImpl <em>suprogram</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.suprogramImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getsuprogram()
	 * @generated
	 */
	int SUPROGRAM = 5;

	/**
	 * The feature id for the '<em><b>Subcomponents</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPROGRAM__SUBCOMPONENTS = 0;

	/**
	 * The feature id for the '<em><b>Annexe</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPROGRAM__ANNEXE = 1;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPROGRAM__NOM = 2;

	/**
	 * The feature id for the '<em><b>Parameterss</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPROGRAM__PARAMETERSS = 3;

	/**
	 * The number of structural features of the '<em>suprogram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPROGRAM_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>suprogram</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPROGRAM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.featureImpl <em>feature</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.featureImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getfeature()
	 * @generated
	 */
	int FEATURE = 6;

	/**
	 * The feature id for the '<em><b>Ports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE__PORTS = 0;

	/**
	 * The feature id for the '<em><b>Access</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE__ACCESS = 1;

	/**
	 * The number of structural features of the '<em>feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.portImpl <em>port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.portImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getport()
	 * @generated
	 */
	int PORT = 7;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__NOM = 1;

	/**
	 * The number of structural features of the '<em>port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.AccesImpl <em>Acces</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.AccesImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getAcces()
	 * @generated
	 */
	int ACCES = 8;

	/**
	 * The feature id for the '<em><b>Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCES__PROTOCOL = 0;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCES__NOM = 1;

	/**
	 * The number of structural features of the '<em>Acces</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCES_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Acces</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACCES_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.connectionImpl <em>connection</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.connectionImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getconnection()
	 * @generated
	 */
	int CONNECTION = 9;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION__NOM = 0;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION__SOURCE = 1;

	/**
	 * The feature id for the '<em><b>Cible</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION__CIBLE = 2;

	/**
	 * The number of structural features of the '<em>connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>connection</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.annexImpl <em>annex</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.annexImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getannex()
	 * @generated
	 */
	int ANNEX = 10;

	/**
	 * The feature id for the '<em><b>States</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNEX__STATES = 0;

	/**
	 * The feature id for the '<em><b>Transitions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNEX__TRANSITIONS = 1;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNEX__NOM = 2;

	/**
	 * The number of structural features of the '<em>annex</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNEX_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>annex</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ANNEX_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.stateImpl <em>state</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.stateImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getstate()
	 * @generated
	 */
	int STATE = 11;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__NOM = 1;

	/**
	 * The number of structural features of the '<em>state</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>state</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.transitionImpl <em>transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.transitionImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#gettransition()
	 * @generated
	 */
	int TRANSITION = 12;

	/**
	 * The feature id for the '<em><b>Gard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__GARD = 0;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__ACTION = 1;

	/**
	 * The feature id for the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__SOURCE = 2;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__TARGET = 3;

	/**
	 * The feature id for the '<em><b>Modifie</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__MODIFIE = 4;

	/**
	 * The feature id for the '<em><b>Etat</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__ETAT = 5;

	/**
	 * The number of structural features of the '<em>transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.connectionthreadImpl <em>connectionthread</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.connectionthreadImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getconnectionthread()
	 * @generated
	 */
	int CONNECTIONTHREAD = 13;

	/**
	 * The feature id for the '<em><b>Sources</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIONTHREAD__SOURCES = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIONTHREAD__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIONTHREAD__NOM = 2;

	/**
	 * The number of structural features of the '<em>connectionthread</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIONTHREAD_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>connectionthread</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONNECTIONTHREAD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.parameterImpl <em>parameter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.parameterImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getparameter()
	 * @generated
	 */
	int PARAMETER = 14;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__NOM = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER__TYPE = 1;

	/**
	 * The number of structural features of the '<em>parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>parameter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.PortINImpl <em>Port IN</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.PortINImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getPortIN()
	 * @generated
	 */
	int PORT_IN = 15;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_IN__TYPE = PORT__TYPE;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_IN__NOM = PORT__NOM;

	/**
	 * The number of structural features of the '<em>Port IN</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_IN_FEATURE_COUNT = PORT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Port IN</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_IN_OPERATION_COUNT = PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link aadldesr.impl.PortOutImpl <em>Port Out</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.impl.PortOutImpl
	 * @see aadldesr.impl.AadldesrPackageImpl#getPortOut()
	 * @generated
	 */
	int PORT_OUT = 16;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OUT__TYPE = PORT__TYPE;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OUT__NOM = PORT__NOM;

	/**
	 * The number of structural features of the '<em>Port Out</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OUT_FEATURE_COUNT = PORT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Port Out</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OUT_OPERATION_COUNT = PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link aadldesr.TDispatch_Protocol <em>TDispatch Protocol</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.TDispatch_Protocol
	 * @see aadldesr.impl.AadldesrPackageImpl#getTDispatch_Protocol()
	 * @generated
	 */
	int TDISPATCH_PROTOCOL = 17;

	/**
	 * The meta object id for the '{@link aadldesr.Tderection <em>Tderection</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.Tderection
	 * @see aadldesr.impl.AadldesrPackageImpl#getTderection()
	 * @generated
	 */
	int TDERECTION = 18;

	/**
	 * The meta object id for the '{@link aadldesr.Ttype <em>Ttype</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.Ttype
	 * @see aadldesr.impl.AadldesrPackageImpl#getTtype()
	 * @generated
	 */
	int TTYPE = 19;

	/**
	 * The meta object id for the '{@link aadldesr.Tprotocol <em>Tprotocol</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.Tprotocol
	 * @see aadldesr.impl.AadldesrPackageImpl#getTprotocol()
	 * @generated
	 */
	int TPROTOCOL = 20;

	/**
	 * The meta object id for the '{@link aadldesr.Tetat <em>Tetat</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see aadldesr.Tetat
	 * @see aadldesr.impl.AadldesrPackageImpl#getTetat()
	 * @generated
	 */
	int TETAT = 21;


	/**
	 * Returns the meta object for class '{@link aadldesr.AADLspec <em>AAD Lspec</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>AAD Lspec</em>'.
	 * @see aadldesr.AADLspec
	 * @generated
	 */
	EClass getAADLspec();

	/**
	 * Returns the meta object for the containment reference '{@link aadldesr.AADLspec#getCompose <em>Compose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Compose</em>'.
	 * @see aadldesr.AADLspec#getCompose()
	 * @see #getAADLspec()
	 * @generated
	 */
	EReference getAADLspec_Compose();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.AADLspec#getDatas <em>Datas</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Datas</em>'.
	 * @see aadldesr.AADLspec#getDatas()
	 * @see #getAADLspec()
	 * @generated
	 */
	EReference getAADLspec_Datas();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.AADLspec#getProcessus <em>Processus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Processus</em>'.
	 * @see aadldesr.AADLspec#getProcessus()
	 * @see #getAADLspec()
	 * @generated
	 */
	EReference getAADLspec_Processus();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.AADLspec#getThreads <em>Threads</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Threads</em>'.
	 * @see aadldesr.AADLspec#getThreads()
	 * @see #getAADLspec()
	 * @generated
	 */
	EReference getAADLspec_Threads();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.AADLspec#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.AADLspec#getNom()
	 * @see #getAADLspec()
	 * @generated
	 */
	EAttribute getAADLspec_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.system <em>system</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>system</em>'.
	 * @see aadldesr.system
	 * @generated
	 */
	EClass getsystem();

	/**
	 * Returns the meta object for the reference list '{@link aadldesr.system#getSubcomponents <em>Subcomponents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subcomponents</em>'.
	 * @see aadldesr.system#getSubcomponents()
	 * @see #getsystem()
	 * @generated
	 */
	EReference getsystem_Subcomponents();

	/**
	 * Returns the meta object for the reference list '{@link aadldesr.system#getSubcomponentsp <em>Subcomponentsp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subcomponentsp</em>'.
	 * @see aadldesr.system#getSubcomponentsp()
	 * @see #getsystem()
	 * @generated
	 */
	EReference getsystem_Subcomponentsp();

	/**
	 * Returns the meta object for the containment reference '{@link aadldesr.system#getFeatures <em>Features</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Features</em>'.
	 * @see aadldesr.system#getFeatures()
	 * @see #getsystem()
	 * @generated
	 */
	EReference getsystem_Features();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.system#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.system#getNom()
	 * @see #getsystem()
	 * @generated
	 */
	EAttribute getsystem_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.data <em>data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>data</em>'.
	 * @see aadldesr.data
	 * @generated
	 */
	EClass getdata();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.data#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see aadldesr.data#getValue()
	 * @see #getdata()
	 * @generated
	 */
	EAttribute getdata_Value();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.data#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.data#getNom()
	 * @see #getdata()
	 * @generated
	 */
	EAttribute getdata_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.process <em>process</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>process</em>'.
	 * @see aadldesr.process
	 * @generated
	 */
	EClass getprocess();

	/**
	 * Returns the meta object for the reference '{@link aadldesr.process#getSubcd <em>Subcd</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Subcd</em>'.
	 * @see aadldesr.process#getSubcd()
	 * @see #getprocess()
	 * @generated
	 */
	EReference getprocess_Subcd();

	/**
	 * Returns the meta object for the reference list '{@link aadldesr.process#getSubccompenets <em>Subccompenets</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subccompenets</em>'.
	 * @see aadldesr.process#getSubccompenets()
	 * @see #getprocess()
	 * @generated
	 */
	EReference getprocess_Subccompenets();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.process#getConnectiont <em>Connectiont</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Connectiont</em>'.
	 * @see aadldesr.process#getConnectiont()
	 * @see #getprocess()
	 * @generated
	 */
	EReference getprocess_Connectiont();

	/**
	 * Returns the meta object for the containment reference '{@link aadldesr.process#getFeatures <em>Features</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Features</em>'.
	 * @see aadldesr.process#getFeatures()
	 * @see #getprocess()
	 * @generated
	 */
	EReference getprocess_Features();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.process#getConnections <em>Connections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Connections</em>'.
	 * @see aadldesr.process#getConnections()
	 * @see #getprocess()
	 * @generated
	 */
	EReference getprocess_Connections();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.process#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.process#getNom()
	 * @see #getprocess()
	 * @generated
	 */
	EAttribute getprocess_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.thread <em>thread</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>thread</em>'.
	 * @see aadldesr.thread
	 * @generated
	 */
	EClass getthread();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.thread#getDispatch_protocol <em>Dispatch protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dispatch protocol</em>'.
	 * @see aadldesr.thread#getDispatch_protocol()
	 * @see #getthread()
	 * @generated
	 */
	EAttribute getthread_Dispatch_protocol();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.thread#getCompute_execution_time <em>Compute execution time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Compute execution time</em>'.
	 * @see aadldesr.thread#getCompute_execution_time()
	 * @see #getthread()
	 * @generated
	 */
	EAttribute getthread_Compute_execution_time();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.thread#getCall <em>Call</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Call</em>'.
	 * @see aadldesr.thread#getCall()
	 * @see #getthread()
	 * @generated
	 */
	EReference getthread_Call();

	/**
	 * Returns the meta object for the containment reference '{@link aadldesr.thread#getAnnexe <em>Annexe</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Annexe</em>'.
	 * @see aadldesr.thread#getAnnexe()
	 * @see #getthread()
	 * @generated
	 */
	EReference getthread_Annexe();

	/**
	 * Returns the meta object for the containment reference '{@link aadldesr.thread#getFeatures <em>Features</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Features</em>'.
	 * @see aadldesr.thread#getFeatures()
	 * @see #getthread()
	 * @generated
	 */
	EReference getthread_Features();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.thread#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.thread#getNom()
	 * @see #getthread()
	 * @generated
	 */
	EAttribute getthread_Nom();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.thread#getConnections <em>Connections</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Connections</em>'.
	 * @see aadldesr.thread#getConnections()
	 * @see #getthread()
	 * @generated
	 */
	EReference getthread_Connections();

	/**
	 * Returns the meta object for class '{@link aadldesr.suprogram <em>suprogram</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>suprogram</em>'.
	 * @see aadldesr.suprogram
	 * @generated
	 */
	EClass getsuprogram();

	/**
	 * Returns the meta object for the reference list '{@link aadldesr.suprogram#getSubcomponents <em>Subcomponents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Subcomponents</em>'.
	 * @see aadldesr.suprogram#getSubcomponents()
	 * @see #getsuprogram()
	 * @generated
	 */
	EReference getsuprogram_Subcomponents();

	/**
	 * Returns the meta object for the containment reference '{@link aadldesr.suprogram#getAnnexe <em>Annexe</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Annexe</em>'.
	 * @see aadldesr.suprogram#getAnnexe()
	 * @see #getsuprogram()
	 * @generated
	 */
	EReference getsuprogram_Annexe();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.suprogram#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.suprogram#getNom()
	 * @see #getsuprogram()
	 * @generated
	 */
	EAttribute getsuprogram_Nom();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.suprogram#getParameterss <em>Parameterss</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Parameterss</em>'.
	 * @see aadldesr.suprogram#getParameterss()
	 * @see #getsuprogram()
	 * @generated
	 */
	EReference getsuprogram_Parameterss();

	/**
	 * Returns the meta object for class '{@link aadldesr.feature <em>feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>feature</em>'.
	 * @see aadldesr.feature
	 * @generated
	 */
	EClass getfeature();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.feature#getPorts <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ports</em>'.
	 * @see aadldesr.feature#getPorts()
	 * @see #getfeature()
	 * @generated
	 */
	EReference getfeature_Ports();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.feature#getAccess <em>Access</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Access</em>'.
	 * @see aadldesr.feature#getAccess()
	 * @see #getfeature()
	 * @generated
	 */
	EReference getfeature_Access();

	/**
	 * Returns the meta object for class '{@link aadldesr.port <em>port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>port</em>'.
	 * @see aadldesr.port
	 * @generated
	 */
	EClass getport();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.port#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see aadldesr.port#getType()
	 * @see #getport()
	 * @generated
	 */
	EAttribute getport_Type();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.port#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.port#getNom()
	 * @see #getport()
	 * @generated
	 */
	EAttribute getport_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.Acces <em>Acces</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Acces</em>'.
	 * @see aadldesr.Acces
	 * @generated
	 */
	EClass getAcces();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.Acces#getProtocol <em>Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Protocol</em>'.
	 * @see aadldesr.Acces#getProtocol()
	 * @see #getAcces()
	 * @generated
	 */
	EAttribute getAcces_Protocol();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.Acces#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.Acces#getNom()
	 * @see #getAcces()
	 * @generated
	 */
	EAttribute getAcces_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.connection <em>connection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>connection</em>'.
	 * @see aadldesr.connection
	 * @generated
	 */
	EClass getconnection();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.connection#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.connection#getNom()
	 * @see #getconnection()
	 * @generated
	 */
	EAttribute getconnection_Nom();

	/**
	 * Returns the meta object for the reference '{@link aadldesr.connection#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see aadldesr.connection#getSource()
	 * @see #getconnection()
	 * @generated
	 */
	EReference getconnection_Source();

	/**
	 * Returns the meta object for the reference '{@link aadldesr.connection#getCible <em>Cible</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cible</em>'.
	 * @see aadldesr.connection#getCible()
	 * @see #getconnection()
	 * @generated
	 */
	EReference getconnection_Cible();

	/**
	 * Returns the meta object for class '{@link aadldesr.annex <em>annex</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>annex</em>'.
	 * @see aadldesr.annex
	 * @generated
	 */
	EClass getannex();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.annex#getStates <em>States</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>States</em>'.
	 * @see aadldesr.annex#getStates()
	 * @see #getannex()
	 * @generated
	 */
	EReference getannex_States();

	/**
	 * Returns the meta object for the containment reference list '{@link aadldesr.annex#getTransitions <em>Transitions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transitions</em>'.
	 * @see aadldesr.annex#getTransitions()
	 * @see #getannex()
	 * @generated
	 */
	EReference getannex_Transitions();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.annex#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.annex#getNom()
	 * @see #getannex()
	 * @generated
	 */
	EAttribute getannex_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.state <em>state</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>state</em>'.
	 * @see aadldesr.state
	 * @generated
	 */
	EClass getstate();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.state#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see aadldesr.state#getType()
	 * @see #getstate()
	 * @generated
	 */
	EAttribute getstate_Type();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.state#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.state#getNom()
	 * @see #getstate()
	 * @generated
	 */
	EAttribute getstate_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.transition <em>transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>transition</em>'.
	 * @see aadldesr.transition
	 * @generated
	 */
	EClass gettransition();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.transition#getGard <em>Gard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Gard</em>'.
	 * @see aadldesr.transition#getGard()
	 * @see #gettransition()
	 * @generated
	 */
	EAttribute gettransition_Gard();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.transition#getAction <em>Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Action</em>'.
	 * @see aadldesr.transition#getAction()
	 * @see #gettransition()
	 * @generated
	 */
	EAttribute gettransition_Action();

	/**
	 * Returns the meta object for the reference '{@link aadldesr.transition#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Source</em>'.
	 * @see aadldesr.transition#getSource()
	 * @see #gettransition()
	 * @generated
	 */
	EReference gettransition_Source();

	/**
	 * Returns the meta object for the reference '{@link aadldesr.transition#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see aadldesr.transition#getTarget()
	 * @see #gettransition()
	 * @generated
	 */
	EReference gettransition_Target();

	/**
	 * Returns the meta object for the reference list '{@link aadldesr.transition#getModifie <em>Modifie</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Modifie</em>'.
	 * @see aadldesr.transition#getModifie()
	 * @see #gettransition()
	 * @generated
	 */
	EReference gettransition_Modifie();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.transition#getEtat <em>Etat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Etat</em>'.
	 * @see aadldesr.transition#getEtat()
	 * @see #gettransition()
	 * @generated
	 */
	EAttribute gettransition_Etat();

	/**
	 * Returns the meta object for class '{@link aadldesr.connectionthread <em>connectionthread</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>connectionthread</em>'.
	 * @see aadldesr.connectionthread
	 * @generated
	 */
	EClass getconnectionthread();

	/**
	 * Returns the meta object for the reference '{@link aadldesr.connectionthread#getSources <em>Sources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Sources</em>'.
	 * @see aadldesr.connectionthread#getSources()
	 * @see #getconnectionthread()
	 * @generated
	 */
	EReference getconnectionthread_Sources();

	/**
	 * Returns the meta object for the reference '{@link aadldesr.connectionthread#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Target</em>'.
	 * @see aadldesr.connectionthread#getTarget()
	 * @see #getconnectionthread()
	 * @generated
	 */
	EReference getconnectionthread_Target();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.connectionthread#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.connectionthread#getNom()
	 * @see #getconnectionthread()
	 * @generated
	 */
	EAttribute getconnectionthread_Nom();

	/**
	 * Returns the meta object for class '{@link aadldesr.parameter <em>parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>parameter</em>'.
	 * @see aadldesr.parameter
	 * @generated
	 */
	EClass getparameter();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.parameter#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see aadldesr.parameter#getNom()
	 * @see #getparameter()
	 * @generated
	 */
	EAttribute getparameter_Nom();

	/**
	 * Returns the meta object for the attribute '{@link aadldesr.parameter#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see aadldesr.parameter#getType()
	 * @see #getparameter()
	 * @generated
	 */
	EAttribute getparameter_Type();

	/**
	 * Returns the meta object for class '{@link aadldesr.PortIN <em>Port IN</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port IN</em>'.
	 * @see aadldesr.PortIN
	 * @generated
	 */
	EClass getPortIN();

	/**
	 * Returns the meta object for class '{@link aadldesr.PortOut <em>Port Out</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port Out</em>'.
	 * @see aadldesr.PortOut
	 * @generated
	 */
	EClass getPortOut();

	/**
	 * Returns the meta object for enum '{@link aadldesr.TDispatch_Protocol <em>TDispatch Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>TDispatch Protocol</em>'.
	 * @see aadldesr.TDispatch_Protocol
	 * @generated
	 */
	EEnum getTDispatch_Protocol();

	/**
	 * Returns the meta object for enum '{@link aadldesr.Tderection <em>Tderection</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Tderection</em>'.
	 * @see aadldesr.Tderection
	 * @generated
	 */
	EEnum getTderection();

	/**
	 * Returns the meta object for enum '{@link aadldesr.Ttype <em>Ttype</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Ttype</em>'.
	 * @see aadldesr.Ttype
	 * @generated
	 */
	EEnum getTtype();

	/**
	 * Returns the meta object for enum '{@link aadldesr.Tprotocol <em>Tprotocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Tprotocol</em>'.
	 * @see aadldesr.Tprotocol
	 * @generated
	 */
	EEnum getTprotocol();

	/**
	 * Returns the meta object for enum '{@link aadldesr.Tetat <em>Tetat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Tetat</em>'.
	 * @see aadldesr.Tetat
	 * @generated
	 */
	EEnum getTetat();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	AadldesrFactory getAadldesrFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link aadldesr.impl.AADLspecImpl <em>AAD Lspec</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.AADLspecImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getAADLspec()
		 * @generated
		 */
		EClass AAD_LSPEC = eINSTANCE.getAADLspec();

		/**
		 * The meta object literal for the '<em><b>Compose</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AAD_LSPEC__COMPOSE = eINSTANCE.getAADLspec_Compose();

		/**
		 * The meta object literal for the '<em><b>Datas</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AAD_LSPEC__DATAS = eINSTANCE.getAADLspec_Datas();

		/**
		 * The meta object literal for the '<em><b>Processus</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AAD_LSPEC__PROCESSUS = eINSTANCE.getAADLspec_Processus();

		/**
		 * The meta object literal for the '<em><b>Threads</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AAD_LSPEC__THREADS = eINSTANCE.getAADLspec_Threads();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AAD_LSPEC__NOM = eINSTANCE.getAADLspec_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.systemImpl <em>system</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.systemImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getsystem()
		 * @generated
		 */
		EClass SYSTEM = eINSTANCE.getsystem();

		/**
		 * The meta object literal for the '<em><b>Subcomponents</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM__SUBCOMPONENTS = eINSTANCE.getsystem_Subcomponents();

		/**
		 * The meta object literal for the '<em><b>Subcomponentsp</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM__SUBCOMPONENTSP = eINSTANCE.getsystem_Subcomponentsp();

		/**
		 * The meta object literal for the '<em><b>Features</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SYSTEM__FEATURES = eINSTANCE.getsystem_Features();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SYSTEM__NOM = eINSTANCE.getsystem_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.dataImpl <em>data</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.dataImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getdata()
		 * @generated
		 */
		EClass DATA = eINSTANCE.getdata();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA__VALUE = eINSTANCE.getdata_Value();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATA__NOM = eINSTANCE.getdata_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.processImpl <em>process</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.processImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getprocess()
		 * @generated
		 */
		EClass PROCESS = eINSTANCE.getprocess();

		/**
		 * The meta object literal for the '<em><b>Subcd</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__SUBCD = eINSTANCE.getprocess_Subcd();

		/**
		 * The meta object literal for the '<em><b>Subccompenets</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__SUBCCOMPENETS = eINSTANCE.getprocess_Subccompenets();

		/**
		 * The meta object literal for the '<em><b>Connectiont</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__CONNECTIONT = eINSTANCE.getprocess_Connectiont();

		/**
		 * The meta object literal for the '<em><b>Features</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__FEATURES = eINSTANCE.getprocess_Features();

		/**
		 * The meta object literal for the '<em><b>Connections</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROCESS__CONNECTIONS = eINSTANCE.getprocess_Connections();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROCESS__NOM = eINSTANCE.getprocess_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.threadImpl <em>thread</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.threadImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getthread()
		 * @generated
		 */
		EClass THREAD = eINSTANCE.getthread();

		/**
		 * The meta object literal for the '<em><b>Dispatch protocol</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THREAD__DISPATCH_PROTOCOL = eINSTANCE.getthread_Dispatch_protocol();

		/**
		 * The meta object literal for the '<em><b>Compute execution time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THREAD__COMPUTE_EXECUTION_TIME = eINSTANCE.getthread_Compute_execution_time();

		/**
		 * The meta object literal for the '<em><b>Call</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THREAD__CALL = eINSTANCE.getthread_Call();

		/**
		 * The meta object literal for the '<em><b>Annexe</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THREAD__ANNEXE = eINSTANCE.getthread_Annexe();

		/**
		 * The meta object literal for the '<em><b>Features</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THREAD__FEATURES = eINSTANCE.getthread_Features();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THREAD__NOM = eINSTANCE.getthread_Nom();

		/**
		 * The meta object literal for the '<em><b>Connections</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference THREAD__CONNECTIONS = eINSTANCE.getthread_Connections();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.suprogramImpl <em>suprogram</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.suprogramImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getsuprogram()
		 * @generated
		 */
		EClass SUPROGRAM = eINSTANCE.getsuprogram();

		/**
		 * The meta object literal for the '<em><b>Subcomponents</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SUPROGRAM__SUBCOMPONENTS = eINSTANCE.getsuprogram_Subcomponents();

		/**
		 * The meta object literal for the '<em><b>Annexe</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SUPROGRAM__ANNEXE = eINSTANCE.getsuprogram_Annexe();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUPROGRAM__NOM = eINSTANCE.getsuprogram_Nom();

		/**
		 * The meta object literal for the '<em><b>Parameterss</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SUPROGRAM__PARAMETERSS = eINSTANCE.getsuprogram_Parameterss();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.featureImpl <em>feature</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.featureImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getfeature()
		 * @generated
		 */
		EClass FEATURE = eINSTANCE.getfeature();

		/**
		 * The meta object literal for the '<em><b>Ports</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE__PORTS = eINSTANCE.getfeature_Ports();

		/**
		 * The meta object literal for the '<em><b>Access</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE__ACCESS = eINSTANCE.getfeature_Access();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.portImpl <em>port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.portImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getport()
		 * @generated
		 */
		EClass PORT = eINSTANCE.getport();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__TYPE = eINSTANCE.getport_Type();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__NOM = eINSTANCE.getport_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.AccesImpl <em>Acces</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.AccesImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getAcces()
		 * @generated
		 */
		EClass ACCES = eINSTANCE.getAcces();

		/**
		 * The meta object literal for the '<em><b>Protocol</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACCES__PROTOCOL = eINSTANCE.getAcces_Protocol();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACCES__NOM = eINSTANCE.getAcces_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.connectionImpl <em>connection</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.connectionImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getconnection()
		 * @generated
		 */
		EClass CONNECTION = eINSTANCE.getconnection();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONNECTION__NOM = eINSTANCE.getconnection_Nom();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTION__SOURCE = eINSTANCE.getconnection_Source();

		/**
		 * The meta object literal for the '<em><b>Cible</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTION__CIBLE = eINSTANCE.getconnection_Cible();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.annexImpl <em>annex</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.annexImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getannex()
		 * @generated
		 */
		EClass ANNEX = eINSTANCE.getannex();

		/**
		 * The meta object literal for the '<em><b>States</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANNEX__STATES = eINSTANCE.getannex_States();

		/**
		 * The meta object literal for the '<em><b>Transitions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ANNEX__TRANSITIONS = eINSTANCE.getannex_Transitions();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ANNEX__NOM = eINSTANCE.getannex_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.stateImpl <em>state</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.stateImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getstate()
		 * @generated
		 */
		EClass STATE = eINSTANCE.getstate();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__TYPE = eINSTANCE.getstate_Type();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__NOM = eINSTANCE.getstate_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.transitionImpl <em>transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.transitionImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#gettransition()
		 * @generated
		 */
		EClass TRANSITION = eINSTANCE.gettransition();

		/**
		 * The meta object literal for the '<em><b>Gard</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSITION__GARD = eINSTANCE.gettransition_Gard();

		/**
		 * The meta object literal for the '<em><b>Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSITION__ACTION = eINSTANCE.gettransition_Action();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__SOURCE = eINSTANCE.gettransition_Source();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__TARGET = eINSTANCE.gettransition_Target();

		/**
		 * The meta object literal for the '<em><b>Modifie</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__MODIFIE = eINSTANCE.gettransition_Modifie();

		/**
		 * The meta object literal for the '<em><b>Etat</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSITION__ETAT = eINSTANCE.gettransition_Etat();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.connectionthreadImpl <em>connectionthread</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.connectionthreadImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getconnectionthread()
		 * @generated
		 */
		EClass CONNECTIONTHREAD = eINSTANCE.getconnectionthread();

		/**
		 * The meta object literal for the '<em><b>Sources</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTIONTHREAD__SOURCES = eINSTANCE.getconnectionthread_Sources();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONNECTIONTHREAD__TARGET = eINSTANCE.getconnectionthread_Target();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONNECTIONTHREAD__NOM = eINSTANCE.getconnectionthread_Nom();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.parameterImpl <em>parameter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.parameterImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getparameter()
		 * @generated
		 */
		EClass PARAMETER = eINSTANCE.getparameter();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__NOM = eINSTANCE.getparameter_Nom();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETER__TYPE = eINSTANCE.getparameter_Type();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.PortINImpl <em>Port IN</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.PortINImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getPortIN()
		 * @generated
		 */
		EClass PORT_IN = eINSTANCE.getPortIN();

		/**
		 * The meta object literal for the '{@link aadldesr.impl.PortOutImpl <em>Port Out</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.impl.PortOutImpl
		 * @see aadldesr.impl.AadldesrPackageImpl#getPortOut()
		 * @generated
		 */
		EClass PORT_OUT = eINSTANCE.getPortOut();

		/**
		 * The meta object literal for the '{@link aadldesr.TDispatch_Protocol <em>TDispatch Protocol</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.TDispatch_Protocol
		 * @see aadldesr.impl.AadldesrPackageImpl#getTDispatch_Protocol()
		 * @generated
		 */
		EEnum TDISPATCH_PROTOCOL = eINSTANCE.getTDispatch_Protocol();

		/**
		 * The meta object literal for the '{@link aadldesr.Tderection <em>Tderection</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.Tderection
		 * @see aadldesr.impl.AadldesrPackageImpl#getTderection()
		 * @generated
		 */
		EEnum TDERECTION = eINSTANCE.getTderection();

		/**
		 * The meta object literal for the '{@link aadldesr.Ttype <em>Ttype</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.Ttype
		 * @see aadldesr.impl.AadldesrPackageImpl#getTtype()
		 * @generated
		 */
		EEnum TTYPE = eINSTANCE.getTtype();

		/**
		 * The meta object literal for the '{@link aadldesr.Tprotocol <em>Tprotocol</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.Tprotocol
		 * @see aadldesr.impl.AadldesrPackageImpl#getTprotocol()
		 * @generated
		 */
		EEnum TPROTOCOL = eINSTANCE.getTprotocol();

		/**
		 * The meta object literal for the '{@link aadldesr.Tetat <em>Tetat</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see aadldesr.Tetat
		 * @see aadldesr.impl.AadldesrPackageImpl#getTetat()
		 * @generated
		 */
		EEnum TETAT = eINSTANCE.getTetat();

	}

} //AadldesrPackage
