/**
 */
package aadldesr;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>system</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link aadldesr.system#getSubcomponents <em>Subcomponents</em>}</li>
 *   <li>{@link aadldesr.system#getSubcomponentsp <em>Subcomponentsp</em>}</li>
 *   <li>{@link aadldesr.system#getFeatures <em>Features</em>}</li>
 *   <li>{@link aadldesr.system#getNom <em>Nom</em>}</li>
 * </ul>
 * </p>
 *
 * @see aadldesr.AadldesrPackage#getsystem()
 * @model
 * @generated
 */
public interface system extends EObject {
	/**
	 * Returns the value of the '<em><b>Subcomponents</b></em>' reference list.
	 * The list contents are of type {@link aadldesr.data}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subcomponents</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subcomponents</em>' reference list.
	 * @see aadldesr.AadldesrPackage#getsystem_Subcomponents()
	 * @model required="true"
	 * @generated
	 */
	EList<data> getSubcomponents();

	/**
	 * Returns the value of the '<em><b>Subcomponentsp</b></em>' reference list.
	 * The list contents are of type {@link aadldesr.process}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subcomponentsp</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subcomponentsp</em>' reference list.
	 * @see aadldesr.AadldesrPackage#getsystem_Subcomponentsp()
	 * @model required="true"
	 * @generated
	 */
	EList<process> getSubcomponentsp();

	/**
	 * Returns the value of the '<em><b>Features</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Features</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Features</em>' containment reference.
	 * @see #setFeatures(feature)
	 * @see aadldesr.AadldesrPackage#getsystem_Features()
	 * @model containment="true"
	 * @generated
	 */
	feature getFeatures();

	/**
	 * Sets the value of the '{@link aadldesr.system#getFeatures <em>Features</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Features</em>' containment reference.
	 * @see #getFeatures()
	 * @generated
	 */
	void setFeatures(feature value);

	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nom</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see aadldesr.AadldesrPackage#getsystem_Nom()
	 * @model
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link aadldesr.system#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

} // system
