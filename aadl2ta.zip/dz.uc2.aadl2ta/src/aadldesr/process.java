/**
 */
package aadldesr;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>process</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link aadldesr.process#getSubcd <em>Subcd</em>}</li>
 *   <li>{@link aadldesr.process#getSubccompenets <em>Subccompenets</em>}</li>
 *   <li>{@link aadldesr.process#getConnectiont <em>Connectiont</em>}</li>
 *   <li>{@link aadldesr.process#getFeatures <em>Features</em>}</li>
 *   <li>{@link aadldesr.process#getConnections <em>Connections</em>}</li>
 *   <li>{@link aadldesr.process#getNom <em>Nom</em>}</li>
 * </ul>
 * </p>
 *
 * @see aadldesr.AadldesrPackage#getprocess()
 * @model
 * @generated
 */
public interface process extends EObject {
	/**
	 * Returns the value of the '<em><b>Subcd</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subcd</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subcd</em>' reference.
	 * @see #setSubcd(data)
	 * @see aadldesr.AadldesrPackage#getprocess_Subcd()
	 * @model required="true"
	 * @generated
	 */
	data getSubcd();

	/**
	 * Sets the value of the '{@link aadldesr.process#getSubcd <em>Subcd</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Subcd</em>' reference.
	 * @see #getSubcd()
	 * @generated
	 */
	void setSubcd(data value);

	/**
	 * Returns the value of the '<em><b>Subccompenets</b></em>' reference list.
	 * The list contents are of type {@link aadldesr.thread}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Subccompenets</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Subccompenets</em>' reference list.
	 * @see aadldesr.AadldesrPackage#getprocess_Subccompenets()
	 * @model required="true"
	 * @generated
	 */
	EList<thread> getSubccompenets();

	/**
	 * Returns the value of the '<em><b>Connectiont</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.connectionthread}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connectiont</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connectiont</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getprocess_Connectiont()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<connectionthread> getConnectiont();

	/**
	 * Returns the value of the '<em><b>Features</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Features</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Features</em>' containment reference.
	 * @see #setFeatures(feature)
	 * @see aadldesr.AadldesrPackage#getprocess_Features()
	 * @model containment="true" required="true"
	 * @generated
	 */
	feature getFeatures();

	/**
	 * Sets the value of the '{@link aadldesr.process#getFeatures <em>Features</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Features</em>' containment reference.
	 * @see #getFeatures()
	 * @generated
	 */
	void setFeatures(feature value);

	/**
	 * Returns the value of the '<em><b>Connections</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.connection}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connections</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connections</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getprocess_Connections()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<connection> getConnections();

	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nom</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see aadldesr.AadldesrPackage#getprocess_Nom()
	 * @model
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link aadldesr.process#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

} // process
