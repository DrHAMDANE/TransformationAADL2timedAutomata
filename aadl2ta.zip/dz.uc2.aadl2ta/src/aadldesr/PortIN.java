/**
 */
package aadldesr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port IN</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see aadldesr.AadldesrPackage#getPortIN()
 * @model
 * @generated
 */
public interface PortIN extends port {
} // PortIN
