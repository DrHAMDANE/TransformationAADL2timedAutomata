/**
 */
package aadldesr;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>thread</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link aadldesr.thread#getDispatch_protocol <em>Dispatch protocol</em>}</li>
 *   <li>{@link aadldesr.thread#getCompute_execution_time <em>Compute execution time</em>}</li>
 *   <li>{@link aadldesr.thread#getCall <em>Call</em>}</li>
 *   <li>{@link aadldesr.thread#getAnnexe <em>Annexe</em>}</li>
 *   <li>{@link aadldesr.thread#getFeatures <em>Features</em>}</li>
 *   <li>{@link aadldesr.thread#getNom <em>Nom</em>}</li>
 *   <li>{@link aadldesr.thread#getConnections <em>Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @see aadldesr.AadldesrPackage#getthread()
 * @model
 * @generated
 */
public interface thread extends EObject {
	/**
	 * Returns the value of the '<em><b>Dispatch protocol</b></em>' attribute.
	 * The literals are from the enumeration {@link aadldesr.TDispatch_Protocol}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Dispatch protocol</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dispatch protocol</em>' attribute.
	 * @see aadldesr.TDispatch_Protocol
	 * @see #setDispatch_protocol(TDispatch_Protocol)
	 * @see aadldesr.AadldesrPackage#getthread_Dispatch_protocol()
	 * @model
	 * @generated
	 */
	TDispatch_Protocol getDispatch_protocol();

	/**
	 * Sets the value of the '{@link aadldesr.thread#getDispatch_protocol <em>Dispatch protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dispatch protocol</em>' attribute.
	 * @see aadldesr.TDispatch_Protocol
	 * @see #getDispatch_protocol()
	 * @generated
	 */
	void setDispatch_protocol(TDispatch_Protocol value);

	/**
	 * Returns the value of the '<em><b>Compute execution time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Compute execution time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Compute execution time</em>' attribute.
	 * @see #setCompute_execution_time(int)
	 * @see aadldesr.AadldesrPackage#getthread_Compute_execution_time()
	 * @model
	 * @generated
	 */
	int getCompute_execution_time();

	/**
	 * Sets the value of the '{@link aadldesr.thread#getCompute_execution_time <em>Compute execution time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Compute execution time</em>' attribute.
	 * @see #getCompute_execution_time()
	 * @generated
	 */
	void setCompute_execution_time(int value);

	/**
	 * Returns the value of the '<em><b>Call</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.suprogram}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Call</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Call</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getthread_Call()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<suprogram> getCall();

	/**
	 * Returns the value of the '<em><b>Annexe</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Annexe</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Annexe</em>' containment reference.
	 * @see #setAnnexe(annex)
	 * @see aadldesr.AadldesrPackage#getthread_Annexe()
	 * @model containment="true" required="true"
	 * @generated
	 */
	annex getAnnexe();

	/**
	 * Sets the value of the '{@link aadldesr.thread#getAnnexe <em>Annexe</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Annexe</em>' containment reference.
	 * @see #getAnnexe()
	 * @generated
	 */
	void setAnnexe(annex value);

	/**
	 * Returns the value of the '<em><b>Features</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Features</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Features</em>' containment reference.
	 * @see #setFeatures(feature)
	 * @see aadldesr.AadldesrPackage#getthread_Features()
	 * @model containment="true" required="true"
	 * @generated
	 */
	feature getFeatures();

	/**
	 * Sets the value of the '{@link aadldesr.thread#getFeatures <em>Features</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Features</em>' containment reference.
	 * @see #getFeatures()
	 * @generated
	 */
	void setFeatures(feature value);

	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nom</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see aadldesr.AadldesrPackage#getthread_Nom()
	 * @model
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link aadldesr.thread#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Connections</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.connection}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Connections</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Connections</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getthread_Connections()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<connection> getConnections();

} // thread
