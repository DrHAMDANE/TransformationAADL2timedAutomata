/**
 */
package aadldesr.impl;

import aadldesr.AadldesrPackage;
import aadldesr.connection;
import aadldesr.connectionthread;
import aadldesr.data;
import aadldesr.feature;
import aadldesr.process;
import aadldesr.thread;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>process</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link aadldesr.impl.processImpl#getSubcd <em>Subcd</em>}</li>
 *   <li>{@link aadldesr.impl.processImpl#getSubccompenets <em>Subccompenets</em>}</li>
 *   <li>{@link aadldesr.impl.processImpl#getConnectiont <em>Connectiont</em>}</li>
 *   <li>{@link aadldesr.impl.processImpl#getFeatures <em>Features</em>}</li>
 *   <li>{@link aadldesr.impl.processImpl#getConnections <em>Connections</em>}</li>
 *   <li>{@link aadldesr.impl.processImpl#getNom <em>Nom</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class processImpl extends MinimalEObjectImpl.Container implements process {
	/**
	 * The cached value of the '{@link #getSubcd() <em>Subcd</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubcd()
	 * @generated
	 * @ordered
	 */
	protected data subcd;

	/**
	 * The cached value of the '{@link #getSubccompenets() <em>Subccompenets</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubccompenets()
	 * @generated
	 * @ordered
	 */
	protected EList<thread> subccompenets;

	/**
	 * The cached value of the '{@link #getConnectiont() <em>Connectiont</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnectiont()
	 * @generated
	 * @ordered
	 */
	protected EList<connectionthread> connectiont;

	/**
	 * The cached value of the '{@link #getFeatures() <em>Features</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFeatures()
	 * @generated
	 * @ordered
	 */
	protected feature features;

	/**
	 * The cached value of the '{@link #getConnections() <em>Connections</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnections()
	 * @generated
	 * @ordered
	 */
	protected EList<connection> connections;

	/**
	 * The default value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected static final String NOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected String nom = NOM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected processImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AadldesrPackage.Literals.PROCESS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public data getSubcd() {
		if (subcd != null && subcd.eIsProxy()) {
			InternalEObject oldSubcd = (InternalEObject)subcd;
			subcd = (data)eResolveProxy(oldSubcd);
			if (subcd != oldSubcd) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AadldesrPackage.PROCESS__SUBCD, oldSubcd, subcd));
			}
		}
		return subcd;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public data basicGetSubcd() {
		return subcd;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSubcd(data newSubcd) {
		data oldSubcd = subcd;
		subcd = newSubcd;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.PROCESS__SUBCD, oldSubcd, subcd));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<thread> getSubccompenets() {
		if (subccompenets == null) {
			subccompenets = new EObjectResolvingEList<thread>(thread.class, this, AadldesrPackage.PROCESS__SUBCCOMPENETS);
		}
		return subccompenets;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<connectionthread> getConnectiont() {
		if (connectiont == null) {
			connectiont = new EObjectContainmentEList<connectionthread>(connectionthread.class, this, AadldesrPackage.PROCESS__CONNECTIONT);
		}
		return connectiont;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public feature getFeatures() {
		return features;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFeatures(feature newFeatures, NotificationChain msgs) {
		feature oldFeatures = features;
		features = newFeatures;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AadldesrPackage.PROCESS__FEATURES, oldFeatures, newFeatures);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFeatures(feature newFeatures) {
		if (newFeatures != features) {
			NotificationChain msgs = null;
			if (features != null)
				msgs = ((InternalEObject)features).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.PROCESS__FEATURES, null, msgs);
			if (newFeatures != null)
				msgs = ((InternalEObject)newFeatures).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.PROCESS__FEATURES, null, msgs);
			msgs = basicSetFeatures(newFeatures, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.PROCESS__FEATURES, newFeatures, newFeatures));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<connection> getConnections() {
		if (connections == null) {
			connections = new EObjectContainmentEList<connection>(connection.class, this, AadldesrPackage.PROCESS__CONNECTIONS);
		}
		return connections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNom(String newNom) {
		String oldNom = nom;
		nom = newNom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.PROCESS__NOM, oldNom, nom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AadldesrPackage.PROCESS__CONNECTIONT:
				return ((InternalEList<?>)getConnectiont()).basicRemove(otherEnd, msgs);
			case AadldesrPackage.PROCESS__FEATURES:
				return basicSetFeatures(null, msgs);
			case AadldesrPackage.PROCESS__CONNECTIONS:
				return ((InternalEList<?>)getConnections()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AadldesrPackage.PROCESS__SUBCD:
				if (resolve) return getSubcd();
				return basicGetSubcd();
			case AadldesrPackage.PROCESS__SUBCCOMPENETS:
				return getSubccompenets();
			case AadldesrPackage.PROCESS__CONNECTIONT:
				return getConnectiont();
			case AadldesrPackage.PROCESS__FEATURES:
				return getFeatures();
			case AadldesrPackage.PROCESS__CONNECTIONS:
				return getConnections();
			case AadldesrPackage.PROCESS__NOM:
				return getNom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AadldesrPackage.PROCESS__SUBCD:
				setSubcd((data)newValue);
				return;
			case AadldesrPackage.PROCESS__SUBCCOMPENETS:
				getSubccompenets().clear();
				getSubccompenets().addAll((Collection<? extends thread>)newValue);
				return;
			case AadldesrPackage.PROCESS__CONNECTIONT:
				getConnectiont().clear();
				getConnectiont().addAll((Collection<? extends connectionthread>)newValue);
				return;
			case AadldesrPackage.PROCESS__FEATURES:
				setFeatures((feature)newValue);
				return;
			case AadldesrPackage.PROCESS__CONNECTIONS:
				getConnections().clear();
				getConnections().addAll((Collection<? extends connection>)newValue);
				return;
			case AadldesrPackage.PROCESS__NOM:
				setNom((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AadldesrPackage.PROCESS__SUBCD:
				setSubcd((data)null);
				return;
			case AadldesrPackage.PROCESS__SUBCCOMPENETS:
				getSubccompenets().clear();
				return;
			case AadldesrPackage.PROCESS__CONNECTIONT:
				getConnectiont().clear();
				return;
			case AadldesrPackage.PROCESS__FEATURES:
				setFeatures((feature)null);
				return;
			case AadldesrPackage.PROCESS__CONNECTIONS:
				getConnections().clear();
				return;
			case AadldesrPackage.PROCESS__NOM:
				setNom(NOM_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AadldesrPackage.PROCESS__SUBCD:
				return subcd != null;
			case AadldesrPackage.PROCESS__SUBCCOMPENETS:
				return subccompenets != null && !subccompenets.isEmpty();
			case AadldesrPackage.PROCESS__CONNECTIONT:
				return connectiont != null && !connectiont.isEmpty();
			case AadldesrPackage.PROCESS__FEATURES:
				return features != null;
			case AadldesrPackage.PROCESS__CONNECTIONS:
				return connections != null && !connections.isEmpty();
			case AadldesrPackage.PROCESS__NOM:
				return NOM_EDEFAULT == null ? nom != null : !NOM_EDEFAULT.equals(nom);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (nom: ");
		result.append(nom);
		result.append(')');
		return result.toString();
	}

} //processImpl
