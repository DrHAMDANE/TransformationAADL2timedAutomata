/**
 */
package aadldesr.impl;

import aadldesr.AadldesrPackage;
import aadldesr.TDispatch_Protocol;
import aadldesr.annex;
import aadldesr.connection;
import aadldesr.feature;
import aadldesr.suprogram;
import aadldesr.thread;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>thread</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link aadldesr.impl.threadImpl#getDispatch_protocol <em>Dispatch protocol</em>}</li>
 *   <li>{@link aadldesr.impl.threadImpl#getCompute_execution_time <em>Compute execution time</em>}</li>
 *   <li>{@link aadldesr.impl.threadImpl#getCall <em>Call</em>}</li>
 *   <li>{@link aadldesr.impl.threadImpl#getAnnexe <em>Annexe</em>}</li>
 *   <li>{@link aadldesr.impl.threadImpl#getFeatures <em>Features</em>}</li>
 *   <li>{@link aadldesr.impl.threadImpl#getNom <em>Nom</em>}</li>
 *   <li>{@link aadldesr.impl.threadImpl#getConnections <em>Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class threadImpl extends MinimalEObjectImpl.Container implements thread {
	/**
	 * The default value of the '{@link #getDispatch_protocol() <em>Dispatch protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDispatch_protocol()
	 * @generated
	 * @ordered
	 */
	protected static final TDispatch_Protocol DISPATCH_PROTOCOL_EDEFAULT = TDispatch_Protocol.PERIODIC;

	/**
	 * The cached value of the '{@link #getDispatch_protocol() <em>Dispatch protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDispatch_protocol()
	 * @generated
	 * @ordered
	 */
	protected TDispatch_Protocol dispatch_protocol = DISPATCH_PROTOCOL_EDEFAULT;

	/**
	 * The default value of the '{@link #getCompute_execution_time() <em>Compute execution time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompute_execution_time()
	 * @generated
	 * @ordered
	 */
	protected static final int COMPUTE_EXECUTION_TIME_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCompute_execution_time() <em>Compute execution time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompute_execution_time()
	 * @generated
	 * @ordered
	 */
	protected int compute_execution_time = COMPUTE_EXECUTION_TIME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCall() <em>Call</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCall()
	 * @generated
	 * @ordered
	 */
	protected EList<suprogram> call;

	/**
	 * The cached value of the '{@link #getAnnexe() <em>Annexe</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnnexe()
	 * @generated
	 * @ordered
	 */
	protected annex annexe;

	/**
	 * The cached value of the '{@link #getFeatures() <em>Features</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFeatures()
	 * @generated
	 * @ordered
	 */
	protected feature features;

	/**
	 * The default value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected static final String NOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected String nom = NOM_EDEFAULT;

	/**
	 * The cached value of the '{@link #getConnections() <em>Connections</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConnections()
	 * @generated
	 * @ordered
	 */
	protected EList<connection> connections;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected threadImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AadldesrPackage.Literals.THREAD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TDispatch_Protocol getDispatch_protocol() {
		return dispatch_protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDispatch_protocol(TDispatch_Protocol newDispatch_protocol) {
		TDispatch_Protocol oldDispatch_protocol = dispatch_protocol;
		dispatch_protocol = newDispatch_protocol == null ? DISPATCH_PROTOCOL_EDEFAULT : newDispatch_protocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.THREAD__DISPATCH_PROTOCOL, oldDispatch_protocol, dispatch_protocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCompute_execution_time() {
		return compute_execution_time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCompute_execution_time(int newCompute_execution_time) {
		int oldCompute_execution_time = compute_execution_time;
		compute_execution_time = newCompute_execution_time;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.THREAD__COMPUTE_EXECUTION_TIME, oldCompute_execution_time, compute_execution_time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<suprogram> getCall() {
		if (call == null) {
			call = new EObjectContainmentEList<suprogram>(suprogram.class, this, AadldesrPackage.THREAD__CALL);
		}
		return call;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public annex getAnnexe() {
		return annexe;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAnnexe(annex newAnnexe, NotificationChain msgs) {
		annex oldAnnexe = annexe;
		annexe = newAnnexe;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AadldesrPackage.THREAD__ANNEXE, oldAnnexe, newAnnexe);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAnnexe(annex newAnnexe) {
		if (newAnnexe != annexe) {
			NotificationChain msgs = null;
			if (annexe != null)
				msgs = ((InternalEObject)annexe).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.THREAD__ANNEXE, null, msgs);
			if (newAnnexe != null)
				msgs = ((InternalEObject)newAnnexe).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.THREAD__ANNEXE, null, msgs);
			msgs = basicSetAnnexe(newAnnexe, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.THREAD__ANNEXE, newAnnexe, newAnnexe));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public feature getFeatures() {
		return features;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFeatures(feature newFeatures, NotificationChain msgs) {
		feature oldFeatures = features;
		features = newFeatures;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AadldesrPackage.THREAD__FEATURES, oldFeatures, newFeatures);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFeatures(feature newFeatures) {
		if (newFeatures != features) {
			NotificationChain msgs = null;
			if (features != null)
				msgs = ((InternalEObject)features).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.THREAD__FEATURES, null, msgs);
			if (newFeatures != null)
				msgs = ((InternalEObject)newFeatures).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.THREAD__FEATURES, null, msgs);
			msgs = basicSetFeatures(newFeatures, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.THREAD__FEATURES, newFeatures, newFeatures));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNom(String newNom) {
		String oldNom = nom;
		nom = newNom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.THREAD__NOM, oldNom, nom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<connection> getConnections() {
		if (connections == null) {
			connections = new EObjectContainmentEList<connection>(connection.class, this, AadldesrPackage.THREAD__CONNECTIONS);
		}
		return connections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AadldesrPackage.THREAD__CALL:
				return ((InternalEList<?>)getCall()).basicRemove(otherEnd, msgs);
			case AadldesrPackage.THREAD__ANNEXE:
				return basicSetAnnexe(null, msgs);
			case AadldesrPackage.THREAD__FEATURES:
				return basicSetFeatures(null, msgs);
			case AadldesrPackage.THREAD__CONNECTIONS:
				return ((InternalEList<?>)getConnections()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AadldesrPackage.THREAD__DISPATCH_PROTOCOL:
				return getDispatch_protocol();
			case AadldesrPackage.THREAD__COMPUTE_EXECUTION_TIME:
				return getCompute_execution_time();
			case AadldesrPackage.THREAD__CALL:
				return getCall();
			case AadldesrPackage.THREAD__ANNEXE:
				return getAnnexe();
			case AadldesrPackage.THREAD__FEATURES:
				return getFeatures();
			case AadldesrPackage.THREAD__NOM:
				return getNom();
			case AadldesrPackage.THREAD__CONNECTIONS:
				return getConnections();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AadldesrPackage.THREAD__DISPATCH_PROTOCOL:
				setDispatch_protocol((TDispatch_Protocol)newValue);
				return;
			case AadldesrPackage.THREAD__COMPUTE_EXECUTION_TIME:
				setCompute_execution_time((Integer)newValue);
				return;
			case AadldesrPackage.THREAD__CALL:
				getCall().clear();
				getCall().addAll((Collection<? extends suprogram>)newValue);
				return;
			case AadldesrPackage.THREAD__ANNEXE:
				setAnnexe((annex)newValue);
				return;
			case AadldesrPackage.THREAD__FEATURES:
				setFeatures((feature)newValue);
				return;
			case AadldesrPackage.THREAD__NOM:
				setNom((String)newValue);
				return;
			case AadldesrPackage.THREAD__CONNECTIONS:
				getConnections().clear();
				getConnections().addAll((Collection<? extends connection>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AadldesrPackage.THREAD__DISPATCH_PROTOCOL:
				setDispatch_protocol(DISPATCH_PROTOCOL_EDEFAULT);
				return;
			case AadldesrPackage.THREAD__COMPUTE_EXECUTION_TIME:
				setCompute_execution_time(COMPUTE_EXECUTION_TIME_EDEFAULT);
				return;
			case AadldesrPackage.THREAD__CALL:
				getCall().clear();
				return;
			case AadldesrPackage.THREAD__ANNEXE:
				setAnnexe((annex)null);
				return;
			case AadldesrPackage.THREAD__FEATURES:
				setFeatures((feature)null);
				return;
			case AadldesrPackage.THREAD__NOM:
				setNom(NOM_EDEFAULT);
				return;
			case AadldesrPackage.THREAD__CONNECTIONS:
				getConnections().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AadldesrPackage.THREAD__DISPATCH_PROTOCOL:
				return dispatch_protocol != DISPATCH_PROTOCOL_EDEFAULT;
			case AadldesrPackage.THREAD__COMPUTE_EXECUTION_TIME:
				return compute_execution_time != COMPUTE_EXECUTION_TIME_EDEFAULT;
			case AadldesrPackage.THREAD__CALL:
				return call != null && !call.isEmpty();
			case AadldesrPackage.THREAD__ANNEXE:
				return annexe != null;
			case AadldesrPackage.THREAD__FEATURES:
				return features != null;
			case AadldesrPackage.THREAD__NOM:
				return NOM_EDEFAULT == null ? nom != null : !NOM_EDEFAULT.equals(nom);
			case AadldesrPackage.THREAD__CONNECTIONS:
				return connections != null && !connections.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (dispatch_protocol: ");
		result.append(dispatch_protocol);
		result.append(", compute_execution_time: ");
		result.append(compute_execution_time);
		result.append(", nom: ");
		result.append(nom);
		result.append(')');
		return result.toString();
	}

} //threadImpl
