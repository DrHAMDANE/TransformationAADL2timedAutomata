/**
 */
package aadldesr.impl;

import aadldesr.AadldesrPackage;
import aadldesr.data;
import aadldesr.state;
import aadldesr.transition;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>transition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link aadldesr.impl.transitionImpl#getGard <em>Gard</em>}</li>
 *   <li>{@link aadldesr.impl.transitionImpl#getAction <em>Action</em>}</li>
 *   <li>{@link aadldesr.impl.transitionImpl#getSource <em>Source</em>}</li>
 *   <li>{@link aadldesr.impl.transitionImpl#getTarget <em>Target</em>}</li>
 *   <li>{@link aadldesr.impl.transitionImpl#getModifie <em>Modifie</em>}</li>
 *   <li>{@link aadldesr.impl.transitionImpl#getEtat <em>Etat</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class transitionImpl extends MinimalEObjectImpl.Container implements transition {
	/**
	 * The default value of the '{@link #getGard() <em>Gard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGard()
	 * @generated
	 * @ordered
	 */
	protected static final String GARD_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getGard() <em>Gard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGard()
	 * @generated
	 * @ordered
	 */
	protected String gard = GARD_EDEFAULT;

	/**
	 * The default value of the '{@link #getAction() <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction()
	 * @generated
	 * @ordered
	 */
	protected static final String ACTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAction() <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction()
	 * @generated
	 * @ordered
	 */
	protected String action = ACTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSource() <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource()
	 * @generated
	 * @ordered
	 */
	protected state source;

	/**
	 * The cached value of the '{@link #getTarget() <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTarget()
	 * @generated
	 * @ordered
	 */
	protected state target;

	/**
	 * The cached value of the '{@link #getModifie() <em>Modifie</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModifie()
	 * @generated
	 * @ordered
	 */
	protected EList<data> modifie;

	/**
	 * The default value of the '{@link #getEtat() <em>Etat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEtat()
	 * @generated
	 * @ordered
	 */
	protected static final String ETAT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEtat() <em>Etat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEtat()
	 * @generated
	 * @ordered
	 */
	protected String etat = ETAT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected transitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AadldesrPackage.Literals.TRANSITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getGard() {
		return gard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGard(String newGard) {
		String oldGard = gard;
		gard = newGard;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.TRANSITION__GARD, oldGard, gard));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAction() {
		return action;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAction(String newAction) {
		String oldAction = action;
		action = newAction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.TRANSITION__ACTION, oldAction, action));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public state getSource() {
		if (source != null && source.eIsProxy()) {
			InternalEObject oldSource = (InternalEObject)source;
			source = (state)eResolveProxy(oldSource);
			if (source != oldSource) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AadldesrPackage.TRANSITION__SOURCE, oldSource, source));
			}
		}
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public state basicGetSource() {
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSource(state newSource) {
		state oldSource = source;
		source = newSource;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.TRANSITION__SOURCE, oldSource, source));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public state getTarget() {
		if (target != null && target.eIsProxy()) {
			InternalEObject oldTarget = (InternalEObject)target;
			target = (state)eResolveProxy(oldTarget);
			if (target != oldTarget) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, AadldesrPackage.TRANSITION__TARGET, oldTarget, target));
			}
		}
		return target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public state basicGetTarget() {
		return target;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTarget(state newTarget) {
		state oldTarget = target;
		target = newTarget;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.TRANSITION__TARGET, oldTarget, target));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<data> getModifie() {
		if (modifie == null) {
			modifie = new EObjectResolvingEList<data>(data.class, this, AadldesrPackage.TRANSITION__MODIFIE);
		}
		return modifie;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEtat() {
		return etat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEtat(String newEtat) {
		String oldEtat = etat;
		etat = newEtat;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.TRANSITION__ETAT, oldEtat, etat));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AadldesrPackage.TRANSITION__GARD:
				return getGard();
			case AadldesrPackage.TRANSITION__ACTION:
				return getAction();
			case AadldesrPackage.TRANSITION__SOURCE:
				if (resolve) return getSource();
				return basicGetSource();
			case AadldesrPackage.TRANSITION__TARGET:
				if (resolve) return getTarget();
				return basicGetTarget();
			case AadldesrPackage.TRANSITION__MODIFIE:
				return getModifie();
			case AadldesrPackage.TRANSITION__ETAT:
				return getEtat();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AadldesrPackage.TRANSITION__GARD:
				setGard((String)newValue);
				return;
			case AadldesrPackage.TRANSITION__ACTION:
				setAction((String)newValue);
				return;
			case AadldesrPackage.TRANSITION__SOURCE:
				setSource((state)newValue);
				return;
			case AadldesrPackage.TRANSITION__TARGET:
				setTarget((state)newValue);
				return;
			case AadldesrPackage.TRANSITION__MODIFIE:
				getModifie().clear();
				getModifie().addAll((Collection<? extends data>)newValue);
				return;
			case AadldesrPackage.TRANSITION__ETAT:
				setEtat((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AadldesrPackage.TRANSITION__GARD:
				setGard(GARD_EDEFAULT);
				return;
			case AadldesrPackage.TRANSITION__ACTION:
				setAction(ACTION_EDEFAULT);
				return;
			case AadldesrPackage.TRANSITION__SOURCE:
				setSource((state)null);
				return;
			case AadldesrPackage.TRANSITION__TARGET:
				setTarget((state)null);
				return;
			case AadldesrPackage.TRANSITION__MODIFIE:
				getModifie().clear();
				return;
			case AadldesrPackage.TRANSITION__ETAT:
				setEtat(ETAT_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AadldesrPackage.TRANSITION__GARD:
				return GARD_EDEFAULT == null ? gard != null : !GARD_EDEFAULT.equals(gard);
			case AadldesrPackage.TRANSITION__ACTION:
				return ACTION_EDEFAULT == null ? action != null : !ACTION_EDEFAULT.equals(action);
			case AadldesrPackage.TRANSITION__SOURCE:
				return source != null;
			case AadldesrPackage.TRANSITION__TARGET:
				return target != null;
			case AadldesrPackage.TRANSITION__MODIFIE:
				return modifie != null && !modifie.isEmpty();
			case AadldesrPackage.TRANSITION__ETAT:
				return ETAT_EDEFAULT == null ? etat != null : !ETAT_EDEFAULT.equals(etat);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (gard: ");
		result.append(gard);
		result.append(", action: ");
		result.append(action);
		result.append(", etat: ");
		result.append(etat);
		result.append(')');
		return result.toString();
	}

} //transitionImpl
