/**
 */
package aadldesr.impl;

import aadldesr.AadldesrPackage;
import aadldesr.data;
import aadldesr.feature;
import aadldesr.process;
import aadldesr.system;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>system</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link aadldesr.impl.systemImpl#getSubcomponents <em>Subcomponents</em>}</li>
 *   <li>{@link aadldesr.impl.systemImpl#getSubcomponentsp <em>Subcomponentsp</em>}</li>
 *   <li>{@link aadldesr.impl.systemImpl#getFeatures <em>Features</em>}</li>
 *   <li>{@link aadldesr.impl.systemImpl#getNom <em>Nom</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class systemImpl extends MinimalEObjectImpl.Container implements system {
	/**
	 * The cached value of the '{@link #getSubcomponents() <em>Subcomponents</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubcomponents()
	 * @generated
	 * @ordered
	 */
	protected EList<data> subcomponents;

	/**
	 * The cached value of the '{@link #getSubcomponentsp() <em>Subcomponentsp</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubcomponentsp()
	 * @generated
	 * @ordered
	 */
	protected EList<process> subcomponentsp;

	/**
	 * The cached value of the '{@link #getFeatures() <em>Features</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFeatures()
	 * @generated
	 * @ordered
	 */
	protected feature features;

	/**
	 * The default value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected static final String NOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected String nom = NOM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected systemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AadldesrPackage.Literals.SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<data> getSubcomponents() {
		if (subcomponents == null) {
			subcomponents = new EObjectResolvingEList<data>(data.class, this, AadldesrPackage.SYSTEM__SUBCOMPONENTS);
		}
		return subcomponents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<process> getSubcomponentsp() {
		if (subcomponentsp == null) {
			subcomponentsp = new EObjectResolvingEList<process>(process.class, this, AadldesrPackage.SYSTEM__SUBCOMPONENTSP);
		}
		return subcomponentsp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public feature getFeatures() {
		return features;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetFeatures(feature newFeatures, NotificationChain msgs) {
		feature oldFeatures = features;
		features = newFeatures;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AadldesrPackage.SYSTEM__FEATURES, oldFeatures, newFeatures);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFeatures(feature newFeatures) {
		if (newFeatures != features) {
			NotificationChain msgs = null;
			if (features != null)
				msgs = ((InternalEObject)features).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.SYSTEM__FEATURES, null, msgs);
			if (newFeatures != null)
				msgs = ((InternalEObject)newFeatures).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.SYSTEM__FEATURES, null, msgs);
			msgs = basicSetFeatures(newFeatures, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.SYSTEM__FEATURES, newFeatures, newFeatures));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNom(String newNom) {
		String oldNom = nom;
		nom = newNom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.SYSTEM__NOM, oldNom, nom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AadldesrPackage.SYSTEM__FEATURES:
				return basicSetFeatures(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AadldesrPackage.SYSTEM__SUBCOMPONENTS:
				return getSubcomponents();
			case AadldesrPackage.SYSTEM__SUBCOMPONENTSP:
				return getSubcomponentsp();
			case AadldesrPackage.SYSTEM__FEATURES:
				return getFeatures();
			case AadldesrPackage.SYSTEM__NOM:
				return getNom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AadldesrPackage.SYSTEM__SUBCOMPONENTS:
				getSubcomponents().clear();
				getSubcomponents().addAll((Collection<? extends data>)newValue);
				return;
			case AadldesrPackage.SYSTEM__SUBCOMPONENTSP:
				getSubcomponentsp().clear();
				getSubcomponentsp().addAll((Collection<? extends process>)newValue);
				return;
			case AadldesrPackage.SYSTEM__FEATURES:
				setFeatures((feature)newValue);
				return;
			case AadldesrPackage.SYSTEM__NOM:
				setNom((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AadldesrPackage.SYSTEM__SUBCOMPONENTS:
				getSubcomponents().clear();
				return;
			case AadldesrPackage.SYSTEM__SUBCOMPONENTSP:
				getSubcomponentsp().clear();
				return;
			case AadldesrPackage.SYSTEM__FEATURES:
				setFeatures((feature)null);
				return;
			case AadldesrPackage.SYSTEM__NOM:
				setNom(NOM_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AadldesrPackage.SYSTEM__SUBCOMPONENTS:
				return subcomponents != null && !subcomponents.isEmpty();
			case AadldesrPackage.SYSTEM__SUBCOMPONENTSP:
				return subcomponentsp != null && !subcomponentsp.isEmpty();
			case AadldesrPackage.SYSTEM__FEATURES:
				return features != null;
			case AadldesrPackage.SYSTEM__NOM:
				return NOM_EDEFAULT == null ? nom != null : !NOM_EDEFAULT.equals(nom);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (nom: ");
		result.append(nom);
		result.append(')');
		return result.toString();
	}

} //systemImpl
