/**
 */
package aadldesr.impl;

import aadldesr.AadldesrPackage;
import aadldesr.annex;
import aadldesr.data;
import aadldesr.parameter;
import aadldesr.suprogram;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>suprogram</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link aadldesr.impl.suprogramImpl#getSubcomponents <em>Subcomponents</em>}</li>
 *   <li>{@link aadldesr.impl.suprogramImpl#getAnnexe <em>Annexe</em>}</li>
 *   <li>{@link aadldesr.impl.suprogramImpl#getNom <em>Nom</em>}</li>
 *   <li>{@link aadldesr.impl.suprogramImpl#getParameterss <em>Parameterss</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class suprogramImpl extends MinimalEObjectImpl.Container implements suprogram {
	/**
	 * The cached value of the '{@link #getSubcomponents() <em>Subcomponents</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubcomponents()
	 * @generated
	 * @ordered
	 */
	protected EList<data> subcomponents;

	/**
	 * The cached value of the '{@link #getAnnexe() <em>Annexe</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAnnexe()
	 * @generated
	 * @ordered
	 */
	protected annex annexe;

	/**
	 * The default value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected static final String NOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected String nom = NOM_EDEFAULT;

	/**
	 * The cached value of the '{@link #getParameterss() <em>Parameterss</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameterss()
	 * @generated
	 * @ordered
	 */
	protected EList<parameter> parameterss;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected suprogramImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AadldesrPackage.Literals.SUPROGRAM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<data> getSubcomponents() {
		if (subcomponents == null) {
			subcomponents = new EObjectResolvingEList<data>(data.class, this, AadldesrPackage.SUPROGRAM__SUBCOMPONENTS);
		}
		return subcomponents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public annex getAnnexe() {
		return annexe;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAnnexe(annex newAnnexe, NotificationChain msgs) {
		annex oldAnnexe = annexe;
		annexe = newAnnexe;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AadldesrPackage.SUPROGRAM__ANNEXE, oldAnnexe, newAnnexe);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAnnexe(annex newAnnexe) {
		if (newAnnexe != annexe) {
			NotificationChain msgs = null;
			if (annexe != null)
				msgs = ((InternalEObject)annexe).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.SUPROGRAM__ANNEXE, null, msgs);
			if (newAnnexe != null)
				msgs = ((InternalEObject)newAnnexe).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.SUPROGRAM__ANNEXE, null, msgs);
			msgs = basicSetAnnexe(newAnnexe, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.SUPROGRAM__ANNEXE, newAnnexe, newAnnexe));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNom(String newNom) {
		String oldNom = nom;
		nom = newNom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.SUPROGRAM__NOM, oldNom, nom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<parameter> getParameterss() {
		if (parameterss == null) {
			parameterss = new EObjectContainmentEList<parameter>(parameter.class, this, AadldesrPackage.SUPROGRAM__PARAMETERSS);
		}
		return parameterss;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AadldesrPackage.SUPROGRAM__ANNEXE:
				return basicSetAnnexe(null, msgs);
			case AadldesrPackage.SUPROGRAM__PARAMETERSS:
				return ((InternalEList<?>)getParameterss()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AadldesrPackage.SUPROGRAM__SUBCOMPONENTS:
				return getSubcomponents();
			case AadldesrPackage.SUPROGRAM__ANNEXE:
				return getAnnexe();
			case AadldesrPackage.SUPROGRAM__NOM:
				return getNom();
			case AadldesrPackage.SUPROGRAM__PARAMETERSS:
				return getParameterss();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AadldesrPackage.SUPROGRAM__SUBCOMPONENTS:
				getSubcomponents().clear();
				getSubcomponents().addAll((Collection<? extends data>)newValue);
				return;
			case AadldesrPackage.SUPROGRAM__ANNEXE:
				setAnnexe((annex)newValue);
				return;
			case AadldesrPackage.SUPROGRAM__NOM:
				setNom((String)newValue);
				return;
			case AadldesrPackage.SUPROGRAM__PARAMETERSS:
				getParameterss().clear();
				getParameterss().addAll((Collection<? extends parameter>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AadldesrPackage.SUPROGRAM__SUBCOMPONENTS:
				getSubcomponents().clear();
				return;
			case AadldesrPackage.SUPROGRAM__ANNEXE:
				setAnnexe((annex)null);
				return;
			case AadldesrPackage.SUPROGRAM__NOM:
				setNom(NOM_EDEFAULT);
				return;
			case AadldesrPackage.SUPROGRAM__PARAMETERSS:
				getParameterss().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AadldesrPackage.SUPROGRAM__SUBCOMPONENTS:
				return subcomponents != null && !subcomponents.isEmpty();
			case AadldesrPackage.SUPROGRAM__ANNEXE:
				return annexe != null;
			case AadldesrPackage.SUPROGRAM__NOM:
				return NOM_EDEFAULT == null ? nom != null : !NOM_EDEFAULT.equals(nom);
			case AadldesrPackage.SUPROGRAM__PARAMETERSS:
				return parameterss != null && !parameterss.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (nom: ");
		result.append(nom);
		result.append(')');
		return result.toString();
	}

} //suprogramImpl
