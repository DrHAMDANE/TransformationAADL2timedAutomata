/**
 */
package aadldesr.impl;

import aadldesr.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class AadldesrFactoryImpl extends EFactoryImpl implements AadldesrFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static AadldesrFactory init() {
		try {
			AadldesrFactory theAadldesrFactory = (AadldesrFactory)EPackage.Registry.INSTANCE.getEFactory(AadldesrPackage.eNS_URI);
			if (theAadldesrFactory != null) {
				return theAadldesrFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new AadldesrFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AadldesrFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case AadldesrPackage.AAD_LSPEC: return createAADLspec();
			case AadldesrPackage.SYSTEM: return createsystem();
			case AadldesrPackage.DATA: return createdata();
			case AadldesrPackage.PROCESS: return createprocess();
			case AadldesrPackage.THREAD: return createthread();
			case AadldesrPackage.SUPROGRAM: return createsuprogram();
			case AadldesrPackage.FEATURE: return createfeature();
			case AadldesrPackage.PORT: return createport();
			case AadldesrPackage.ACCES: return createAcces();
			case AadldesrPackage.CONNECTION: return createconnection();
			case AadldesrPackage.ANNEX: return createannex();
			case AadldesrPackage.STATE: return createstate();
			case AadldesrPackage.TRANSITION: return createtransition();
			case AadldesrPackage.CONNECTIONTHREAD: return createconnectionthread();
			case AadldesrPackage.PARAMETER: return createparameter();
			case AadldesrPackage.PORT_IN: return createPortIN();
			case AadldesrPackage.PORT_OUT: return createPortOut();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case AadldesrPackage.TDISPATCH_PROTOCOL:
				return createTDispatch_ProtocolFromString(eDataType, initialValue);
			case AadldesrPackage.TDERECTION:
				return createTderectionFromString(eDataType, initialValue);
			case AadldesrPackage.TTYPE:
				return createTtypeFromString(eDataType, initialValue);
			case AadldesrPackage.TPROTOCOL:
				return createTprotocolFromString(eDataType, initialValue);
			case AadldesrPackage.TETAT:
				return createTetatFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case AadldesrPackage.TDISPATCH_PROTOCOL:
				return convertTDispatch_ProtocolToString(eDataType, instanceValue);
			case AadldesrPackage.TDERECTION:
				return convertTderectionToString(eDataType, instanceValue);
			case AadldesrPackage.TTYPE:
				return convertTtypeToString(eDataType, instanceValue);
			case AadldesrPackage.TPROTOCOL:
				return convertTprotocolToString(eDataType, instanceValue);
			case AadldesrPackage.TETAT:
				return convertTetatToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AADLspec createAADLspec() {
		AADLspecImpl aadLspec = new AADLspecImpl();
		return aadLspec;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public system createsystem() {
		systemImpl system = new systemImpl();
		return system;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public data createdata() {
		dataImpl data = new dataImpl();
		return data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public process createprocess() {
		processImpl process = new processImpl();
		return process;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public thread createthread() {
		threadImpl thread = new threadImpl();
		return thread;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public suprogram createsuprogram() {
		suprogramImpl suprogram = new suprogramImpl();
		return suprogram;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public feature createfeature() {
		featureImpl feature = new featureImpl();
		return feature;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public port createport() {
		portImpl port = new portImpl();
		return port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Acces createAcces() {
		AccesImpl acces = new AccesImpl();
		return acces;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public connection createconnection() {
		connectionImpl connection = new connectionImpl();
		return connection;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public annex createannex() {
		annexImpl annex = new annexImpl();
		return annex;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public state createstate() {
		stateImpl state = new stateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public transition createtransition() {
		transitionImpl transition = new transitionImpl();
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public connectionthread createconnectionthread() {
		connectionthreadImpl connectionthread = new connectionthreadImpl();
		return connectionthread;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public parameter createparameter() {
		parameterImpl parameter = new parameterImpl();
		return parameter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortIN createPortIN() {
		PortINImpl portIN = new PortINImpl();
		return portIN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PortOut createPortOut() {
		PortOutImpl portOut = new PortOutImpl();
		return portOut;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TDispatch_Protocol createTDispatch_ProtocolFromString(EDataType eDataType, String initialValue) {
		TDispatch_Protocol result = TDispatch_Protocol.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTDispatch_ProtocolToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tderection createTderectionFromString(EDataType eDataType, String initialValue) {
		Tderection result = Tderection.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTderectionToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Ttype createTtypeFromString(EDataType eDataType, String initialValue) {
		Ttype result = Ttype.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTtypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tprotocol createTprotocolFromString(EDataType eDataType, String initialValue) {
		Tprotocol result = Tprotocol.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTprotocolToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tetat createTetatFromString(EDataType eDataType, String initialValue) {
		Tetat result = Tetat.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTetatToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AadldesrPackage getAadldesrPackage() {
		return (AadldesrPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static AadldesrPackage getPackage() {
		return AadldesrPackage.eINSTANCE;
	}

} //AadldesrFactoryImpl
