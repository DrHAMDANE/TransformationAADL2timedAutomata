/**
 */
package aadldesr.impl;

import aadldesr.AADLspec;
import aadldesr.AadldesrPackage;
import aadldesr.data;
import aadldesr.process;
import aadldesr.system;
import aadldesr.thread;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>AAD Lspec</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link aadldesr.impl.AADLspecImpl#getCompose <em>Compose</em>}</li>
 *   <li>{@link aadldesr.impl.AADLspecImpl#getDatas <em>Datas</em>}</li>
 *   <li>{@link aadldesr.impl.AADLspecImpl#getProcessus <em>Processus</em>}</li>
 *   <li>{@link aadldesr.impl.AADLspecImpl#getThreads <em>Threads</em>}</li>
 *   <li>{@link aadldesr.impl.AADLspecImpl#getNom <em>Nom</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class AADLspecImpl extends MinimalEObjectImpl.Container implements AADLspec {
	/**
	 * The cached value of the '{@link #getCompose() <em>Compose</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCompose()
	 * @generated
	 * @ordered
	 */
	protected system compose;

	/**
	 * The cached value of the '{@link #getDatas() <em>Datas</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDatas()
	 * @generated
	 * @ordered
	 */
	protected EList<data> datas;

	/**
	 * The cached value of the '{@link #getProcessus() <em>Processus</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProcessus()
	 * @generated
	 * @ordered
	 */
	protected EList<process> processus;

	/**
	 * The cached value of the '{@link #getThreads() <em>Threads</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThreads()
	 * @generated
	 * @ordered
	 */
	protected EList<thread> threads;

	/**
	 * The default value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected static final String NOM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNom() <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNom()
	 * @generated
	 * @ordered
	 */
	protected String nom = NOM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AADLspecImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return AadldesrPackage.Literals.AAD_LSPEC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public system getCompose() {
		return compose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCompose(system newCompose, NotificationChain msgs) {
		system oldCompose = compose;
		compose = newCompose;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, AadldesrPackage.AAD_LSPEC__COMPOSE, oldCompose, newCompose);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCompose(system newCompose) {
		if (newCompose != compose) {
			NotificationChain msgs = null;
			if (compose != null)
				msgs = ((InternalEObject)compose).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.AAD_LSPEC__COMPOSE, null, msgs);
			if (newCompose != null)
				msgs = ((InternalEObject)newCompose).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - AadldesrPackage.AAD_LSPEC__COMPOSE, null, msgs);
			msgs = basicSetCompose(newCompose, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.AAD_LSPEC__COMPOSE, newCompose, newCompose));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<data> getDatas() {
		if (datas == null) {
			datas = new EObjectContainmentEList<data>(data.class, this, AadldesrPackage.AAD_LSPEC__DATAS);
		}
		return datas;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<process> getProcessus() {
		if (processus == null) {
			processus = new EObjectContainmentEList<process>(process.class, this, AadldesrPackage.AAD_LSPEC__PROCESSUS);
		}
		return processus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<thread> getThreads() {
		if (threads == null) {
			threads = new EObjectContainmentEList<thread>(thread.class, this, AadldesrPackage.AAD_LSPEC__THREADS);
		}
		return threads;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNom(String newNom) {
		String oldNom = nom;
		nom = newNom;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, AadldesrPackage.AAD_LSPEC__NOM, oldNom, nom));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case AadldesrPackage.AAD_LSPEC__COMPOSE:
				return basicSetCompose(null, msgs);
			case AadldesrPackage.AAD_LSPEC__DATAS:
				return ((InternalEList<?>)getDatas()).basicRemove(otherEnd, msgs);
			case AadldesrPackage.AAD_LSPEC__PROCESSUS:
				return ((InternalEList<?>)getProcessus()).basicRemove(otherEnd, msgs);
			case AadldesrPackage.AAD_LSPEC__THREADS:
				return ((InternalEList<?>)getThreads()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case AadldesrPackage.AAD_LSPEC__COMPOSE:
				return getCompose();
			case AadldesrPackage.AAD_LSPEC__DATAS:
				return getDatas();
			case AadldesrPackage.AAD_LSPEC__PROCESSUS:
				return getProcessus();
			case AadldesrPackage.AAD_LSPEC__THREADS:
				return getThreads();
			case AadldesrPackage.AAD_LSPEC__NOM:
				return getNom();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case AadldesrPackage.AAD_LSPEC__COMPOSE:
				setCompose((system)newValue);
				return;
			case AadldesrPackage.AAD_LSPEC__DATAS:
				getDatas().clear();
				getDatas().addAll((Collection<? extends data>)newValue);
				return;
			case AadldesrPackage.AAD_LSPEC__PROCESSUS:
				getProcessus().clear();
				getProcessus().addAll((Collection<? extends process>)newValue);
				return;
			case AadldesrPackage.AAD_LSPEC__THREADS:
				getThreads().clear();
				getThreads().addAll((Collection<? extends thread>)newValue);
				return;
			case AadldesrPackage.AAD_LSPEC__NOM:
				setNom((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case AadldesrPackage.AAD_LSPEC__COMPOSE:
				setCompose((system)null);
				return;
			case AadldesrPackage.AAD_LSPEC__DATAS:
				getDatas().clear();
				return;
			case AadldesrPackage.AAD_LSPEC__PROCESSUS:
				getProcessus().clear();
				return;
			case AadldesrPackage.AAD_LSPEC__THREADS:
				getThreads().clear();
				return;
			case AadldesrPackage.AAD_LSPEC__NOM:
				setNom(NOM_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case AadldesrPackage.AAD_LSPEC__COMPOSE:
				return compose != null;
			case AadldesrPackage.AAD_LSPEC__DATAS:
				return datas != null && !datas.isEmpty();
			case AadldesrPackage.AAD_LSPEC__PROCESSUS:
				return processus != null && !processus.isEmpty();
			case AadldesrPackage.AAD_LSPEC__THREADS:
				return threads != null && !threads.isEmpty();
			case AadldesrPackage.AAD_LSPEC__NOM:
				return NOM_EDEFAULT == null ? nom != null : !NOM_EDEFAULT.equals(nom);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (nom: ");
		result.append(nom);
		result.append(')');
		return result.toString();
	}

} //AADLspecImpl
