/**
 */
package aadldesr;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link aadldesr.transition#getGard <em>Gard</em>}</li>
 *   <li>{@link aadldesr.transition#getAction <em>Action</em>}</li>
 *   <li>{@link aadldesr.transition#getSource <em>Source</em>}</li>
 *   <li>{@link aadldesr.transition#getTarget <em>Target</em>}</li>
 *   <li>{@link aadldesr.transition#getModifie <em>Modifie</em>}</li>
 *   <li>{@link aadldesr.transition#getEtat <em>Etat</em>}</li>
 * </ul>
 * </p>
 *
 * @see aadldesr.AadldesrPackage#gettransition()
 * @model
 * @generated
 */
public interface transition extends EObject {
	/**
	 * Returns the value of the '<em><b>Gard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Gard</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gard</em>' attribute.
	 * @see #setGard(String)
	 * @see aadldesr.AadldesrPackage#gettransition_Gard()
	 * @model
	 * @generated
	 */
	String getGard();

	/**
	 * Sets the value of the '{@link aadldesr.transition#getGard <em>Gard</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Gard</em>' attribute.
	 * @see #getGard()
	 * @generated
	 */
	void setGard(String value);

	/**
	 * Returns the value of the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Action</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Action</em>' attribute.
	 * @see #setAction(String)
	 * @see aadldesr.AadldesrPackage#gettransition_Action()
	 * @model
	 * @generated
	 */
	String getAction();

	/**
	 * Sets the value of the '{@link aadldesr.transition#getAction <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Action</em>' attribute.
	 * @see #getAction()
	 * @generated
	 */
	void setAction(String value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(state)
	 * @see aadldesr.AadldesrPackage#gettransition_Source()
	 * @model required="true"
	 * @generated
	 */
	state getSource();

	/**
	 * Sets the value of the '{@link aadldesr.transition#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(state value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(state)
	 * @see aadldesr.AadldesrPackage#gettransition_Target()
	 * @model required="true"
	 * @generated
	 */
	state getTarget();

	/**
	 * Sets the value of the '{@link aadldesr.transition#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(state value);

	/**
	 * Returns the value of the '<em><b>Modifie</b></em>' reference list.
	 * The list contents are of type {@link aadldesr.data}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Modifie</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Modifie</em>' reference list.
	 * @see aadldesr.AadldesrPackage#gettransition_Modifie()
	 * @model required="true"
	 * @generated
	 */
	EList<data> getModifie();

	/**
	 * Returns the value of the '<em><b>Etat</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Etat</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Etat</em>' attribute.
	 * @see #setEtat(String)
	 * @see aadldesr.AadldesrPackage#gettransition_Etat()
	 * @model
	 * @generated
	 */
	String getEtat();

	/**
	 * Sets the value of the '{@link aadldesr.transition#getEtat <em>Etat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Etat</em>' attribute.
	 * @see #getEtat()
	 * @generated
	 */
	void setEtat(String value);

} // transition
