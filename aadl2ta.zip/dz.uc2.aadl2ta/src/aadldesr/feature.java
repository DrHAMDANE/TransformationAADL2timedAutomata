/**
 */
package aadldesr;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>feature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link aadldesr.feature#getPorts <em>Ports</em>}</li>
 *   <li>{@link aadldesr.feature#getAccess <em>Access</em>}</li>
 * </ul>
 * </p>
 *
 * @see aadldesr.AadldesrPackage#getfeature()
 * @model
 * @generated
 */
public interface feature extends EObject {
	/**
	 * Returns the value of the '<em><b>Ports</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.port}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ports</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ports</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getfeature_Ports()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<port> getPorts();

	/**
	 * Returns the value of the '<em><b>Access</b></em>' containment reference list.
	 * The list contents are of type {@link aadldesr.Acces}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Access</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Access</em>' containment reference list.
	 * @see aadldesr.AadldesrPackage#getfeature_Access()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Acces> getAccess();

} // feature
