/**
 */
package aadldesr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port Out</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see aadldesr.AadldesrPackage#getPortOut()
 * @model
 * @generated
 */
public interface PortOut extends port {
} // PortOut
