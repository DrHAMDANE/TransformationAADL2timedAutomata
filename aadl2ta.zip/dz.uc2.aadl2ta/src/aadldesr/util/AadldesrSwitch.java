/**
 */
package aadldesr.util;

import aadldesr.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see aadldesr.AadldesrPackage
 * @generated
 */
public class AadldesrSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static AadldesrPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AadldesrSwitch() {
		if (modelPackage == null) {
			modelPackage = AadldesrPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @parameter ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case AadldesrPackage.AAD_LSPEC: {
				AADLspec aadLspec = (AADLspec)theEObject;
				T result = caseAADLspec(aadLspec);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.SYSTEM: {
				system system = (system)theEObject;
				T result = casesystem(system);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.DATA: {
				data data = (data)theEObject;
				T result = casedata(data);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.PROCESS: {
				process process = (process)theEObject;
				T result = caseprocess(process);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.THREAD: {
				thread thread = (thread)theEObject;
				T result = casethread(thread);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.SUPROGRAM: {
				suprogram suprogram = (suprogram)theEObject;
				T result = casesuprogram(suprogram);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.FEATURE: {
				feature feature = (feature)theEObject;
				T result = casefeature(feature);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.PORT: {
				port port = (port)theEObject;
				T result = caseport(port);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.ACCES: {
				Acces acces = (Acces)theEObject;
				T result = caseAcces(acces);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.CONNECTION: {
				connection connection = (connection)theEObject;
				T result = caseconnection(connection);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.ANNEX: {
				annex annex = (annex)theEObject;
				T result = caseannex(annex);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.STATE: {
				state state = (state)theEObject;
				T result = casestate(state);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.TRANSITION: {
				transition transition = (transition)theEObject;
				T result = casetransition(transition);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.CONNECTIONTHREAD: {
				connectionthread connectionthread = (connectionthread)theEObject;
				T result = caseconnectionthread(connectionthread);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.PARAMETER: {
				parameter parameter = (parameter)theEObject;
				T result = caseparameter(parameter);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.PORT_IN: {
				PortIN portIN = (PortIN)theEObject;
				T result = casePortIN(portIN);
				if (result == null) result = caseport(portIN);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case AadldesrPackage.PORT_OUT: {
				PortOut portOut = (PortOut)theEObject;
				T result = casePortOut(portOut);
				if (result == null) result = caseport(portOut);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>AAD Lspec</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>AAD Lspec</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAADLspec(AADLspec object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>system</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>system</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casesystem(system object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>data</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>data</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casedata(data object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>process</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>process</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseprocess(process object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>thread</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>thread</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casethread(thread object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>suprogram</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>suprogram</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casesuprogram(suprogram object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>feature</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>feature</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casefeature(feature object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>port</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>port</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseport(port object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Acces</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Acces</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAcces(Acces object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>connection</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>connection</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseconnection(connection object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>annex</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>annex</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseannex(annex object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>state</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>state</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casestate(state object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>transition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>transition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casetransition(transition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>connectionthread</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>connectionthread</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseconnectionthread(connectionthread object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>parameter</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>parameter</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseparameter(parameter object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port IN</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port IN</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortIN(PortIN object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Port Out</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Port Out</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePortOut(PortOut object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //AadldesrSwitch
