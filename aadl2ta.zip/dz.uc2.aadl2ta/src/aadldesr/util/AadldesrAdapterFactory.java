/**
 */
package aadldesr.util;

import aadldesr.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see aadldesr.AadldesrPackage
 * @generated
 */
public class AadldesrAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static AadldesrPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AadldesrAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = AadldesrPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AadldesrSwitch<Adapter> modelSwitch =
		new AadldesrSwitch<Adapter>() {
			@Override
			public Adapter caseAADLspec(AADLspec object) {
				return createAADLspecAdapter();
			}
			@Override
			public Adapter casesystem(system object) {
				return createsystemAdapter();
			}
			@Override
			public Adapter casedata(data object) {
				return createdataAdapter();
			}
			@Override
			public Adapter caseprocess(process object) {
				return createprocessAdapter();
			}
			@Override
			public Adapter casethread(thread object) {
				return createthreadAdapter();
			}
			@Override
			public Adapter casesuprogram(suprogram object) {
				return createsuprogramAdapter();
			}
			@Override
			public Adapter casefeature(feature object) {
				return createfeatureAdapter();
			}
			@Override
			public Adapter caseport(port object) {
				return createportAdapter();
			}
			@Override
			public Adapter caseAcces(Acces object) {
				return createAccesAdapter();
			}
			@Override
			public Adapter caseconnection(connection object) {
				return createconnectionAdapter();
			}
			@Override
			public Adapter caseannex(annex object) {
				return createannexAdapter();
			}
			@Override
			public Adapter casestate(state object) {
				return createstateAdapter();
			}
			@Override
			public Adapter casetransition(transition object) {
				return createtransitionAdapter();
			}
			@Override
			public Adapter caseconnectionthread(connectionthread object) {
				return createconnectionthreadAdapter();
			}
			@Override
			public Adapter caseparameter(parameter object) {
				return createparameterAdapter();
			}
			@Override
			public Adapter casePortIN(PortIN object) {
				return createPortINAdapter();
			}
			@Override
			public Adapter casePortOut(PortOut object) {
				return createPortOutAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.AADLspec <em>AAD Lspec</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.AADLspec
	 * @generated
	 */
	public Adapter createAADLspecAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.system <em>system</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.system
	 * @generated
	 */
	public Adapter createsystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.data <em>data</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.data
	 * @generated
	 */
	public Adapter createdataAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.process <em>process</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.process
	 * @generated
	 */
	public Adapter createprocessAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.thread <em>thread</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.thread
	 * @generated
	 */
	public Adapter createthreadAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.suprogram <em>suprogram</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.suprogram
	 * @generated
	 */
	public Adapter createsuprogramAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.feature <em>feature</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.feature
	 * @generated
	 */
	public Adapter createfeatureAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.port <em>port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.port
	 * @generated
	 */
	public Adapter createportAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.Acces <em>Acces</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.Acces
	 * @generated
	 */
	public Adapter createAccesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.connection <em>connection</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.connection
	 * @generated
	 */
	public Adapter createconnectionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.annex <em>annex</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.annex
	 * @generated
	 */
	public Adapter createannexAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.state <em>state</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.state
	 * @generated
	 */
	public Adapter createstateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.transition <em>transition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.transition
	 * @generated
	 */
	public Adapter createtransitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.connectionthread <em>connectionthread</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.connectionthread
	 * @generated
	 */
	public Adapter createconnectionthreadAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.parameter <em>parameter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.parameter
	 * @generated
	 */
	public Adapter createparameterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.PortIN <em>Port IN</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.PortIN
	 * @generated
	 */
	public Adapter createPortINAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link aadldesr.PortOut <em>Port Out</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see aadldesr.PortOut
	 * @generated
	 */
	public Adapter createPortOutAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //AadldesrAdapterFactory
